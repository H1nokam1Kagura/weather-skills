"""NEW-03: narrowly opt four inherited rubrics into mechanical applicability."""
GUARDS = {
    "E01-P2-INJ": ("J2", "verifier_invoked"),
    "E04-P2-INJ": ("J2", "reviewer_first_reject"),
    "E05-P2-INJ": ("J3", "reviewer_invoked"),
    "E06-P2-INJ": ("J3", "reviewer_truncation_exposure"),
}


def apply(ds, mf, req, oq, rulings):
    changed = []
    for suffix, (aid, guard) in GUARDS.items():
        case, = [c for c in ds["cases"] if c["id"].endswith(suffix)]
        assertion, = [a for a in case["assertions"] if a["id"] == aid]
        assert assertion["predicate"]["operator"] == "rubric"
        assertion["predicate"]["legacy_guard"] = guard
        for root in ("invocation_receipts", "controller_trace", "harness_observations") if suffix == "E06-P2-INJ" else ("invocation_receipts",):
            if root not in assertion["evidence_paths"]:
                assertion["evidence_paths"].append(root)
        changed.append({"case": case["id"], "assertion": aid, "guard": guard})
    return changed
