"""NEW-10 contract repairs over a renamed copy of the frozen v2.6 inputs.

This declares prerequisites; it does not implement or verify a live adapter.
"""
from collections import Counter

SIGNAL_CAPTURE = "CAP-SIGNAL-CAPTURE"


def apply(ds, mf, req, oq, rulings):
    """Mutate only case capabilities and adapter manifest; retain owner policy."""
    cases = ds["cases"]
    case_ids = [case["id"] for case in cases]
    if len(case_ids) != len(set(case_ids)):
        raise ValueError("Duplicate case IDs cannot produce an exact capability mapping")
    known = {cap["id"] for cap in mf["capabilities"]}
    required = {cap for case in cases for cap in case["adapter_requirements"]}
    if SIGNAL_CAPTURE not in known or required - known:
        raise ValueError("Case capabilities must have manifest definitions")

    for case in cases:
        case["adapter_requirements"] = sorted(set(case["adapter_requirements"]) | {SIGNAL_CAPTURE})
    mf["case_to_capability_mapping"] = {
        case["id"]: list(case["adapter_requirements"]) for case in cases
    }
    counts = Counter(cap for case in cases for cap in case["adapter_requirements"])
    for capability in mf["capabilities"]:
        capability["cases"] = counts[capability["id"]]

    contracts = {item["id"]: item for item in mf["unresolved_contracts"]}
    contracts["UC-12"].update(
        item=("Adapter compatibility with the RULED UC-12 policy remains UNVERIFIED: "
              "SOURCE_CHECKED must accept CHIRPS-identical system-visible input, including "
              "source lineage. Synthetic provenance remains in a harness-only manifest "
              "and tags on the run and every collected output, never in system-visible input."),
        blocks=list(case_ids),
        blocking_condition=("Applies to every case only if adapter compatibility with the "
                            "ruled visible-input/provenance boundary fails; this is not "
                            "evidence that any or all cases currently fail."),
        policy_status="RULED",
        adapter_compatibility="UNVERIFIED",
    )
    contracts["UC-16"].update(
        item=("RULED exact repair accounting: repair_attempts_used == count(repairer "
              "invocations) <= cap, including NEEDS-INFO and invalid-plan outputs. "
              "Current R15 / UC-15-resume-r2 permits at most TWO automatic resumes. "
              "Attributed human resume requests are not count-capped; accepted resumes "
              "still require re-verification and stay within original time and cost "
              "budgets without resetting counters or changing limits. Adapter "
              "compatibility remains UNVERIFIED."),
        policy_status="RULED",
        adapter_compatibility="UNVERIFIED",
    )
