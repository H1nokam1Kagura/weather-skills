"""Bounded v2.7 closure of confirmed Round 12 defects; no candidate execution."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OLD=ROOT/'casesets/cached-onset-e2e-v2_6'
OLD_SHA='600e2abc262d15233beec2ae7116d1fe91061d62809d41af716c9a5e1e60d12e'
sys.path.insert(0,str(ROOT))
from simkit import contract
from simkit.score import evaluate

def load(path): return json.loads(path.read_text(encoding='utf-8'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def module(name):
    spec=importlib.util.spec_from_file_location('v27_'+name,HERE/(name+'.py'))
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
def rename(x):
    if isinstance(x,str): return x.replace('DEV-E2E-V2_6-','DEV-E2E-V2_7-')
    if isinstance(x,list): return [rename(v) for v in x]
    if isinstance(x,dict): return {rename(k):rename(v) for k,v in x.items()}
    return x

def build():
    source=OLD/'frozen/agentic-e2e-injections.DEV-ONLY.json'
    assert sha(source)==OLD_SHA,'Frozen v2.6 changed'
    previous=load(source)
    ds=rename(previous)
    mf=rename(load(OLD/'frozen/agentic-e2e-injections.ADAPTER-REQUIREMENTS.json'))
    req=copy.deepcopy(load(OLD/'requirements.json'))
    oq=rename(load(OLD/'OPEN-QUESTIONS.json'))
    rulings=copy.deepcopy(load(OLD/'spec-rulings.json'))
    ds['schema_version']='agentic-e2e-injections/2.7'
    mf['schema_version']='agentic-e2e-adapter-requirements/2.7'
    oq['case_set']='cached-onset-e2e-v2_7'
    oq['rulings_file']='casesets/cached-onset-e2e-v2_7/spec-rulings.json'
    rulings['case_set']='cached-onset-e2e-v2_7'
    req['v2_6_checks']=False
    req['v2_7_checks']=True
    req['v2_6_case_ids']=[c['id'] for c in previous['cases']]
    req['v2_7_lineage']={'source_dataset_sha256':OLD_SHA,'scorer_sha256':sha(ROOT/'simkit/score.py')}
    for old,c in zip(previous['cases'],ds['cases']):
        c['supersedes_v2_6_case_ids']=[old['id']]
    # Schedule additions precede capability census so mapping/counts include them.
    for name in ('rubric_fixes','schedule_fixes','capability_fixes'):
        module(name).apply(ds,mf,req,oq,rulings)
    # Only expected legacy rubric outcomes change; mechanical fixtures remain frozen.
    guard_pins={}
    for c in ds['cases']:
        for a in c['assertions']:
            pred=a['predicate']
            if pred['operator']=='rubric':
                guard_pins[c['id']+'/'+a['id']]=hashlib.sha256(json.dumps(pred,sort_keys=True).encode()).hexdigest()
                for b in c['probe_bundles']:
                    if a['id'] in b.get('expect',{}):
                        b['expect'][a['id']]=evaluate(pred,b['evidence'])
    req['v2_7_rubric_predicate_sha256']=guard_pins
    ds['generator_metadata']={
        'case_set_version':'v2.7','method':'Deterministic frozen v2.6 delta: confirmed NEW-03/05/10 only',
        'source_dataset_sha256':OLD_SHA,'owner_rulings_log_sha256':sha(ROOT/'spec-rulings/OWNER-RULINGS-LOG.json'),
        'scorer_sha256_at_generation':sha(ROOT/'simkit/score.py'),
        'builder_sha256_at_generation':sha(Path(__file__)),
        'delta_modules_sha256':{name:sha(HERE/(name+'.py')) for name in ('rubric_fixes','schedule_fixes','capability_fixes')},
        'candidate_executed':False,'ratification_performed':False,
    }
    return ds,mf,req,oq,rulings

def write(out):
    if out.exists(): raise SystemExit(f'Refusing to overwrite {out}')
    ds,mf,req,oq,rulings=build()
    co=contract.build(ds,[],req.get('contract_structures_extra'))
    out.mkdir(parents=True)
    for name,obj in [('agentic-e2e-injections.DEV-ONLY.json',ds),('agentic-e2e-injections.ADAPTER-REQUIREMENTS.json',mf),('requirements.json',req),('OPEN-QUESTIONS.json',oq),('spec-rulings.json',rulings),('EVIDENCE_CONTRACT.json',co),('amendments.json',{'amendments':[]})]:
        (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=1)+'\n',encoding='utf-8',newline='\n')
    (out/'EVIDENCE_CONTRACT.md').write_text(contract.to_markdown(co),encoding='utf-8',newline='\n')
    print(json.dumps({'out':str(out),'cases':len(ds['cases']),'scorer':sha(ROOT/'simkit/score.py')}))

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=HERE/'out/build')
    write(ap.parse_args().out)
