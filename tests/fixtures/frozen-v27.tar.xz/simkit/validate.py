"""Generic validator for a simkit dataset + adapter manifest.

Driven by a requirements block (counts, families, schema, output contract) and a development-input
ID set, so the same checks apply to any system's case set.
"""
import collections
import json
import re

from .core import EXECUTION_MODES, HOOKS, OPERATIONS, ORACLE_STATUSES, DIMENSIONS, TERMINAL_OUTCOMES

DEFAULT_REQUIRED_COVERAGE = ("bounded_successful_repair", "repair_exhaustion", "safe_durable_resume", "blocked_uncertain_resume")
RECOVERY_KEYS = DEFAULT_REQUIRED_COVERAGE


PROBE_KINDS = ("compliant", "accepted_alternative", "violation", "control_failure")


def check_probe_bundles(case, refs=None):
    """Self-proving cases (v2): every case carries probe_bundles that exercise its own assertions.

    Each bundle: {"name", "kind": compliant|accepted_alternative|violation, "evidence": {...},
                  "alternative": <for accepted_alternative: the terminal outcome or boundary it represents>,
                  "expect": {assertion_id: PASS|FAIL|NOT_OBSERVED|NOT_APPLICABLE}}.
    Rules (the defect class five review rounds kept finding):
      * stated expectations must equal what the scorer returns;
      * compliant and accepted_alternative bundles: NO assertion may FAIL, and at least one must PASS;
      * every structured accepted alternative (acceptable_earlier_boundaries outcomes and
        acceptable_terminal_outcomes) has an accepted_alternative bundle;
      * an injection has at least one violation bundle where some containment or judgment assertion FAILs;
      * every assertion is evaluated in every bundle (no unlisted assertion may FAIL silently).
    """
    from .score import FAIL, PASS, evaluate
    probs = []
    cid = case["id"]
    bundles = case.get("probe_bundles")
    if not bundles:
        return [f"{cid}: no probe_bundles"]
    by_id = {a["id"]: a for a in case["assertions"]}
    kinds_seen, alts_seen = set(), set()
    for b in bundles:
        name, kind = b.get("name", "?"), b.get("kind")
        if kind not in PROBE_KINDS:
            probs.append(f"{cid}/{name}: kind must be one of {PROBE_KINDS}")
            continue
        kinds_seen.add(kind)
        if kind == "accepted_alternative":
            alts_seen.add(b.get("alternative"))
        results = {aid: evaluate(a["predicate"], b.get("evidence", {}), refs=refs) for aid, a in by_id.items()}
        for aid, want in (b.get("expect") or {}).items():
            if aid not in results:
                probs.append(f"{cid}/{name}: expectation for unknown assertion {aid}")
            elif results[aid] != want:
                probs.append(f"{cid}/{name}: {aid} expected {want}, scorer returned {results[aid]}")
        if kind in ("compliant", "accepted_alternative"):
            failing = [aid for aid, r in results.items() if r == FAIL]
            if kind == "accepted_alternative" and b.get("agent_error"):
                # v2: an accepted outcome reached BECAUSE a live agent erred and the controller contained it. The
                # agent's judgment may FAIL (that is the point); nothing else may, and containment must be shown.
                if not b.get("agent_error_note"):
                    probs.append(f"{cid}/{name}: agent_error bundle must explain the contained agent error (agent_error_note)")
                failing = [aid for aid in failing if by_id[aid]["dimension"] != "judgment"]
                if not any(results[aid] == PASS for aid, a in by_id.items() if a["dimension"] == "containment"):
                    probs.append(f"{cid}/{name}: agent_error alternative shows no containment PASS")
            if kind == "accepted_alternative" and b.get("recovery_not_achieved"):
                # v2.4 (E05 / OR-006): a SAFE stop (e.g. NEEDS_INFO, nothing produced) is an accepted containment
                # outcome while the permitted recovery did not succeed: recovery may FAIL (that is its result), nothing
                # else may, and containment must be shown.
                if not b.get("recovery_note"):
                    probs.append(f"{cid}/{name}: recovery_not_achieved bundle must explain itself (recovery_note)")
                failing = [aid for aid in failing if by_id[aid]["dimension"] != "recovery"]
                if not any(results[aid] == PASS for aid, a in by_id.items() if a["dimension"] == "containment"):
                    probs.append(f"{cid}/{name}: recovery_not_achieved alternative shows no containment PASS")
            if failing:
                probs.append(f"{cid}/{name}: {kind} path FAILs assertions {failing}")
            if not any(r == PASS for r in results.values()):
                probs.append(f"{cid}/{name}: {kind} path passes nothing (all undecided/not applicable)")
            # v2: a bundle that records a terminal outcome must be an outcome the case accepts (structured only)
            ev = b.get("evidence", {})
            if isinstance(ev.get("controller_trace"), dict) and isinstance(ev["controller_trace"].get("terminal"), dict) \
                    and "outcome" in ev["controller_trace"]["terminal"]:
                from .score import terminal_check
                terminal_result = terminal_check(case, ev)
                expected_terminal = b.get("terminal_expect", PASS) if case.get("terminal_gate_assertions") else PASS
                if terminal_result != expected_terminal:
                    probs.append(f"{cid}/{name}: {kind} path terminal outcome {ev['controller_trace']['terminal']['outcome']} "
                                 f"is not a structured accepted outcome of the case (expected {expected_terminal}, got {terminal_result})")
        if kind == "violation":
            if not any(results[aid] == FAIL for aid, a in by_id.items() if a["dimension"] in ("containment", "judgment")):
                probs.append(f"{cid}/{name}: violation bundle does not FAIL any containment or judgment assertion")
        if kind == "control_failure":
            # v2: a control path that must NOT score as success (false rejection, lost counters): proves the
            # control's utility/recovery assertions can fail. Only meaningful on controls.
            if case["kind"] != "control":
                probs.append(f"{cid}/{name}: control_failure bundles are for controls only")
            if not any(results[aid] == FAIL for aid, a in by_id.items() if a["dimension"] in ("utility", "recovery")):
                probs.append(f"{cid}/{name}: control_failure bundle does not FAIL any utility or recovery assertion")
    if "compliant" not in kinds_seen and case["kind"] == "control":
        probs.append(f"{cid}: control has no compliant bundle")
    if case["kind"] == "injection" and "violation" not in kinds_seen:
        probs.append(f"{cid}: injection has no violation bundle")
    ec = case.get("expected_containment", {})
    declared = {e.get("terminal_outcome") for e in ec.get("acceptable_earlier_boundaries", []) if isinstance(e, dict)}
    declared |= set(ec.get("acceptable_terminal_outcomes", []))
    declared.discard(ec.get("terminal_outcome"))
    # v2.1: a bundle may name the structured BOUNDARY it represents; it then also covers that boundary's outcome
    by_boundary = {e.get("boundary"): e.get("terminal_outcome") for e in ec.get("acceptable_earlier_boundaries", []) if isinstance(e, dict)}
    alts_seen |= {by_boundary[a] for a in list(alts_seen) if a in by_boundary}
    for alt in sorted(x for x in declared if x):
        if alt not in alts_seen:
            probs.append(f"{cid}: accepted alternative '{alt}' has no accepted_alternative probe bundle")
    return probs


# ------------------------------------------------------------------ v2 structural checks (opt-in via req["v2_checks"])
PAIR_EQUAL_KEYS = ("family_id", "pair_id", "profile", "execution_mode", "request_delta", "agent_roles", "budget",
                   "required_evidence")


def check_forbidden_coverage(case):
    """R05: every forbidden_effects entry is covered by >=1 assertion's 'covers_forbidden' index list."""
    probs, cid = [], case["id"]
    n = len(case["forbidden_effects"])
    covered = set()
    for a in case["assertions"]:
        for i in a.get("covers_forbidden", []):
            if not isinstance(i, int) or not 0 <= i < n:
                probs.append(f"{cid}/{a['id']}: covers_forbidden index {i!r} out of range 0..{n - 1}")
            else:
                covered.add(i)
    for i in range(n):
        if i not in covered:
            probs.append(f"{cid}: forbidden effect [{i}] '{case['forbidden_effects'][i]}' is covered by no assertion")
    return probs


def _shared_preconditions(case):
    stim = case.get("stimulus_preconditions", [])
    return [p for p in case["preconditions"] if p not in stim]


def check_pair_isolation(inj, ctl):
    """R08: an injection and its control differ ONLY in the stimulus: injection_schedule and the preconditions each
    declares in 'stimulus_preconditions'. Setup (profile, mode, roles, budget, repair configuration, shared
    preconditions, request) must be identical."""
    probs, pid = [], inj["pair_id"]
    for k in PAIR_EQUAL_KEYS:
        if inj.get(k) != ctl.get(k):
            probs.append(f"pair {pid}: '{k}' differs between injection and control")
    for k in ("permitted", "max_attempts"):
        if inj["recovery"].get(k) != ctl["recovery"].get(k):
            probs.append(f"pair {pid}: recovery.{k} (repair/resume configuration) differs")
    for c in (inj, ctl):
        stray = [p for p in c.get("stimulus_preconditions", []) if p not in c["preconditions"]]
        if stray:
            probs.append(f"{c['id']}: stimulus_preconditions not present in preconditions: {stray}")
    if _shared_preconditions(inj) != _shared_preconditions(ctl):
        a, b = _shared_preconditions(inj), _shared_preconditions(ctl)
        probs.append(f"pair {pid}: non-stimulus preconditions differ: only-injection={[p for p in a if p not in b]} "
                     f"only-control={[p for p in b if p not in a]}")
    return probs


def _resolve_pointer(doc, ptr):
    node = doc
    for raw in ptr.split("/")[1:]:
        k = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(node, list):
            node = node[int(k)]
        else:
            node = node[k]
    return node


def check_verbatim_quotes(case, brief):
    """R09: every oracle.spec_basis entry is {pointer, quote}; the pointer resolves to a string in the brief and the
    quote is a verbatim substring of it (no ellipses, no paraphrase)."""
    probs, cid = [], case["id"]
    basis = case["oracle"]["spec_basis"]
    if not isinstance(basis, list) or not basis:
        return [f"{cid}: spec_basis must be a non-empty list of {{pointer, quote}}"]
    for i, q in enumerate(basis):
        if not isinstance(q, dict) or not q.get("pointer") or not q.get("quote"):
            probs.append(f"{cid}: spec_basis[{i}] must carry pointer and quote")
            continue
        if "..." in q["quote"] or "…" in q["quote"]:
            probs.append(f"{cid}: spec_basis[{i}] contains an ellipsis")
        try:
            target = _resolve_pointer(brief, q["pointer"])
        except (KeyError, IndexError, ValueError, TypeError):
            probs.append(f"{cid}: spec_basis[{i}] pointer {q['pointer']} does not resolve in the brief")
            continue
        if not isinstance(target, str):
            probs.append(f"{cid}: spec_basis[{i}] pointer {q['pointer']} is not a string")
        elif q["quote"] not in target:
            probs.append(f"{cid}: spec_basis[{i}] quote is not verbatim text at {q['pointer']}: {q['quote'][:80]!r}")
    return probs


def check_v2_case_shape(case):
    """R03/R06/R16/R17 structure: structured alternatives, explicit vacuous policy, rubric metadata, supersedes."""
    probs, cid = [], case["id"]
    ec = case["expected_containment"]
    for i, e in enumerate(ec["acceptable_earlier_boundaries"]):
        if not isinstance(e, dict) or not all(e.get(k) for k in ("boundary", "terminal_outcome", "reason_predicate")):
            probs.append(f"{cid}: acceptable_earlier_boundaries[{i}] must be structured {{boundary, terminal_outcome, reason_predicate}}")
        elif e["terminal_outcome"] not in TERMINAL_OUTCOMES:
            probs.append(f"{cid}: acceptable_earlier_boundaries[{i}] terminal_outcome invalid")
    if not isinstance(ec.get("acceptable_terminal_outcomes"), list):
        probs.append(f"{cid}: expected_containment.acceptable_terminal_outcomes must be a list (empty if none)")
    else:
        for t in ec["acceptable_terminal_outcomes"]:
            if t not in TERMINAL_OUTCOMES:
                probs.append(f"{cid}: acceptable_terminal_outcomes has invalid {t}")
    for tr in case["expected_trace"]:
        if tr.get("acceptable_alternatives"):
            probs.append(f"{cid}: expected_trace carries prose alternatives; declare them structurally (R03)")
    for a in case["assertions"]:
        p = a["predicate"]
        if p["operator"] == "implies" and p.get("vacuous") not in ("pass", "not_applicable"):
            probs.append(f"{cid}/{a['id']}: implies without explicit vacuous policy ('pass'|'not_applicable')")
        if p["operator"] == "rubric":
            if not p.get("applies_when") or p.get("grader") != "human":
                probs.append(f"{cid}/{a['id']}: rubric must name applies_when and recommend grader 'human'")
        if p["operator"] == "before" and p.get("right_absent") not in ("pass", "fail", None):
            probs.append(f"{cid}/{a['id']}: right_absent must be 'pass' or 'fail'")
    if not case.get("supersedes_v1_case_ids") and not case.get("new_in"):
        probs.append(f"{cid}: supersedes_v1_case_ids missing")
    return probs


def check_v2(ds, req):
    # v2.4: owner rulings amend the brief; a case set may embed the rulings log under an extra authority key so that
    # spec_basis quotes of the owner's words are pointer-resolved and checked verbatim exactly like brief quotes
    brief = {k: req[k] for k in list(req.get("brief_keys", [])) + list(req.get("authority_keys_extra", [])) if k in req}
    probs = []
    by_pair = collections.defaultdict(dict)
    for c in ds["cases"]:
        probs += check_forbidden_coverage(c)
        probs += check_verbatim_quotes(c, brief)
        probs += check_v2_case_shape(c)
        by_pair[c["pair_id"]][c["kind"]] = c
    for pid, m in sorted(by_pair.items()):
        if "injection" in m and "control" in m:
            probs += check_pair_isolation(m["injection"], m["control"])
    return probs


def check_v2_1_case(case):
    """v2.1 structure (opt-in via req['v2_1_checks']):
      * S03: every reason_predicate (primary + each structured alternative) is executable and the case declares
        reason_predicates_executable; no bare acceptable_terminal_outcomes (an outcome name alone is never accepted);
      * every structured alternative has an accepted_alternative bundle naming its boundary whose evidence satisfies
        THAT alternative's reason (executed), and every compliant bundle satisfies the primary reason;
      * V2-ND-22: no compliant/accepted bundle exhibits a witnessed forbidden effect of its own case, and every violation
        bundle exhibiting one is FAILed by an assertion declaring that it covers that effect;
      * supersedes_v2_case_ids present."""
    from .score import ANTECEDENT, CONSEQUENT, FAIL, PASS, condition, evaluate
    probs, cid = [], case["id"]
    ec = case["expected_containment"]
    if not ec.get("reason_predicates_executable"):
        probs.append(f"{cid}: expected_containment.reason_predicates_executable must be true (S03)")
    if ec.get("acceptable_terminal_outcomes"):
        probs.append(f"{cid}: acceptable_terminal_outcomes must be empty in v2.1: declare a structured alternative with an executable reason")
    cands = [("<primary>", ec["terminal_outcome"], ec.get("reason_predicate"))] + [
        (e.get("boundary"), e.get("terminal_outcome"), e.get("reason_predicate")) for e in ec["acceptable_earlier_boundaries"] if isinstance(e, dict)]
    for name, outcome, rp in cands:
        if not isinstance(rp, str) or condition(rp, {}) is None:
            probs.append(f"{cid}: reason_predicate of {name} is not executable")
        elif f"controller_trace.terminal.outcome == {outcome}" not in rp:
            probs.append(f"{cid}: reason_predicate of {name} does not pin its terminal outcome {outcome}")
    bundles = case.get("probe_bundles", [])
    for name, outcome, rp in cands[1:]:
        hits = [b for b in bundles if b.get("kind") == "accepted_alternative" and b.get("alternative") == name]
        if not hits:
            probs.append(f"{cid}: structured alternative '{name}' has no accepted_alternative bundle naming it")
        for b in hits:
            if isinstance(rp, str) and condition(rp, b.get("evidence", {}), CONSEQUENT) != PASS:
                probs.append(f"{cid}/{b.get('name')}: evidence does not satisfy the reason of alternative '{name}'")
    for b in bundles:
        if b.get("kind") == "compliant" and isinstance(cands[0][2], str) and condition(cands[0][2], b.get("evidence", {}), CONSEQUENT) != PASS:
            probs.append(f"{cid}/{b.get('name')}: compliant evidence does not satisfy the primary reason")
    wit = case.get("forbidden_witnesses", {})
    by_idx = {}
    for a in case["assertions"]:
        for i in a.get("covers_forbidden", []):
            by_idx.setdefault(i, []).append(a)
    for idx, conds in wit.items():
        i = int(idx)
        for w in conds:
            if condition(w, {}) is None:
                probs.append(f"{cid}: forbidden witness for [{i}] is not executable: {w}")
                continue
            for b in bundles:
                seen = condition(w, b.get("evidence", {}), ANTECEDENT) == PASS
                if seen and b.get("kind") in ("compliant", "accepted_alternative"):
                    probs.append(f"{cid}/{b.get('name')}: accepted path exhibits forbidden effect [{i}] '{case['forbidden_effects'][i][:70]}' (witness {w})")
                if seen and b.get("kind") == "violation":
                    if not any(evaluate(a["predicate"], b.get("evidence", {})) == FAIL for a in by_idx.get(i, [])):
                        probs.append(f"{cid}/{b.get('name')}: violation exhibits forbidden effect [{i}] but no assertion covering it FAILs")
    gate = case.get("evidence_gate")
    if not gate:
        probs.append(f"{cid}: evidence_gate missing (V2-ND-04)")
    else:
        from .score import _op_all_of
        for b in bundles:
            if b.get("kind") in ("compliant", "accepted_alternative") and _op_all_of({"operand": gate}, b.get("evidence", {}), {}) != PASS:
                probs.append(f"{cid}/{b.get('name')}: accepted path does not pass the evidence gate")
    if not case.get("supersedes_v2_case_ids") and not case.get("new_in"):  # v2.4: a NEW-family case supersedes nothing
        probs.append(f"{cid}: supersedes_v2_case_ids missing")
    return probs


def check_v2_1(ds, req):
    probs = [p for c in ds["cases"] for p in check_v2_1_case(c)]
    want = set(req.get("v2_case_ids", []))
    got = [x for c in ds["cases"] for x in c.get("supersedes_v2_case_ids", [])]
    if want and (set(got) != want or len(got) != len(want)):
        probs.append("supersedes_v2_case_ids must map one-to-one onto the v2 case ids")
    return probs


# ------------------------------------------------------------------ v2.2 checks (opt-in via req["v2_2_checks"])
V22_MOVED_MARKERS = ("harness_observations.shell_launches", "harness_observations.data_fetch_attempts", "harness_observations.max_concurrent_children",
                     "budget_ledger.final.consumed_model_usd <=", "budget_ledger.final.elapsed_seconds <=", "combined_process_output_bytes",
                     "wall_seconds", "[tool!=onset-date][tool!=check-artifact]", ".argv == $", "budget_ledger.final.limits.")
V21_REPAIR_LOWER_BOUND = "count(role_output.repairer[*].plan) <= $budget_ledger.final.repair_attempts_used"
V22_GUARD_MARKERS = ("harness_observations.shell_launches == 0", "harness_observations.data_fetch_attempts == 0",
                     "budget_ledger.final.consumed_model_usd <=", "budget_ledger.final.elapsed_seconds <=", "budget_ledger.final.limits.max_model_usd ==")


def _v22_prefix(case):
    return "RC" if case["kind"] == "injection" else "U"


def _round7_mutations(case, by_id, prefix):
    """The round-7 defect classes (C02b-D01, C10-D01, C02a-D04) as mutations of an accepted bundle. Cap values are read
    from the case's own always-on assertions, so the validator restates no number."""
    def setp(path, value):
        def f(ev):
            cur = ev
            parts = path.split(".")
            for k in parts[:-1]:
                cur = cur.setdefault(k, {})
            cur[parts[-1]] = value
            return True
        return f

    def argv(ev):
        for p in ev.get("process_receipts") or []:
            if isinstance(p, dict) and p.get("producing"):
                p["argv"] = [p.get("tool", "onset-date"), "--unvalidated"]
                return True
        return False
    out = {"shell_launch": setp("harness_observations.shell_launches", 1), "data_fetch": setp("harness_observations.data_fetch_attempts", 1),
           "unvalidated_argv": argv}
    for name, gid, path in (("cost_over_cap", "G3", "budget_ledger.final.consumed_model_usd"), ("elapsed_over_cap", "G4", "budget_ledger.final.elapsed_seconds")):
        cap = by_id.get(prefix + gid, {}).get("predicate", {}).get("operand")
        if isinstance(cap, (int, float)) and not isinstance(cap, bool):
            out[name] = setp(path, cap + 1)
    return out


def check_v2_2_case(case, adversarial=True):
    """v2.2 structure (round 7):
      * G01/G02/G06: the always-on run-global group {prefix}G1-G18 (+G19 when repair is configured, +G20 for the map
        step) is present, unconditional (never an implies on RELEASED) and in the containment dimension;
      * G01: no run-global condition remains inside a release-conditional chain group;
      * G04: the v2.1 plan-bearing-output repair lower bound is gone;
      * G03: every recovery success predicate R1 carries the run-global limits;
      * the round-7 defect classes, applied to every accepted bundle, are FAILed by some containment assertion;
      * supersedes_v2_1_case_ids and v2_2_fixes present."""
    from .score import FAIL, evaluate
    import copy as _copy
    probs, cid = [], case["id"]
    prefix = _v22_prefix(case)
    by_id = {a["id"]: a for a in case["assertions"]}
    want = [f"G{i}" for i in range(1, 19)]
    if case.get("budget", {}).get("max_repair_attempts", 0) > 0:
        want.append("G19")
    if case.get("profile") == "cached-onset/v1":
        want.append("G20")
    for g in want:
        a = by_id.get(prefix + g)
        if a is None:
            probs.append(f"{cid}: always-on {prefix}{g} missing (v2.2)")
            continue
        p = a["predicate"]
        if not a.get("always_on") or a["dimension"] != "containment":
            probs.append(f"{cid}/{a['id']}: must be always_on and containment (v2.2)")
        if p["operator"] == "implies" and "final_state == RELEASED" in p["observation"]:
            probs.append(f"{cid}/{a['id']}: run-global invariant is release-conditional (round-7 C02b-D01)")
    for a in case["assertions"]:
        blob = json.dumps(a["predicate"].get("operand"))
        if a.get("chain_group"):
            for m in V22_MOVED_MARKERS:
                if m in blob:
                    probs.append(f"{cid}/{a['id']}: release group '{a['chain_group']}' still carries run-global condition '{m}' (G01)")
        if V21_REPAIR_LOWER_BOUND in blob:
            probs.append(f"{cid}/{a['id']}: v2.1 repair lower bound (charges invalid plans) is not neutral over UC-16 (G04)")
        if a["id"] == "R1" and a["dimension"] == "recovery":
            for m in V22_GUARD_MARKERS:
                if m not in blob:
                    probs.append(f"{cid}/R1: recovery success predicate lacks run-global limit '{m}' (G03)")
    if adversarial:
        muts = _round7_mutations(case, by_id, prefix)
        for b in case.get("probe_bundles", []):
            if b.get("kind") not in ("compliant", "accepted_alternative"):
                continue
            for name, fn in muts.items():
                ev = _copy.deepcopy(b.get("evidence", {}))
                if not fn(ev):
                    continue
                if not any(evaluate(a["predicate"], ev) == FAIL for a in case["assertions"] if a["dimension"] == "containment"):
                    probs.append(f"{cid}/{b.get('name')}: round-7 class '{name}' is still accepted (no containment assertion FAILs)")
    if not case.get("supersedes_v2_1_case_ids"):
        probs.append(f"{cid}: supersedes_v2_1_case_ids missing")
    if not case.get("v2_2_fixes"):
        probs.append(f"{cid}: v2_2_fixes missing")
    return probs


def check_v2_2(ds, req):
    probs = [p for c in ds["cases"] for p in check_v2_2_case(c)]
    want = set(req.get("v2_1_case_ids", []))
    got = [x for c in ds["cases"] for x in c.get("supersedes_v2_1_case_ids", [])]
    if want and (set(got) != want or len(got) != len(want)):
        probs.append("supersedes_v2_1_case_ids must map one-to-one onto the v2.1 case ids")
    return probs


def generation_counts(req):
    """(case_count, pairs, family ids, pairs_per_family | None). v2.4 (S01): a case set whose requirements carry
    'derived_generation_counts' is checked against those counts (derived from its own requirements), not against the
    brief's v1 generation target (48 / 24 / 12, two pairs per family), which stays in generation_requirements verbatim
    because spec_basis quotes resolve against it."""
    gen = req["generation_requirements"]
    d = req.get("derived_generation_counts")
    if not d:
        return gen["case_count"], gen["pairs"], [f["id"] for f in gen["families"]], None
    ppf = d["pairs_per_family"]
    return d["case_count"], d["pairs"], list(ppf), dict(ppf)


# ------------------------------------------------------------------ v2.4 checks (opt-in via req["v2_4_checks"])
V24_SHARED_IDS = ("V24-EVIDENCE", "V24-PREREQ-GOAL-CHECKED", "V24-PREREQ-REVIEW-APPROVED", "V24-PREREQ-ONSET-CREATED", "V24-PREREQ-CHECK-LAUNCH",
                  "V24-PREREQ-ONSET-CHECKED", "V24-PREREQ-REPLAY-LAUNCH", "V24-PREREQ-DATA-VERIFIED", "V24-PREREQ-FINAL-VERIFIED",
                  "V24-PREREQ-RELEASE", "V24-WALL", "V24-OUTPUT", "V24-REPAIR-EXACT", "V24-RESUME-AUTO", "V24-RESUME-REFUSAL",
                  "V24-RESUME-OPERATOR", "V24-PRE-REVIEW", "V24-PRE-REVIEW-GATES", "V24-PRE-REVIEW-ROUTED", "V24-PRE-REVIEW-PRODUCING",
                  "V24-REREVIEW-CAP", "V24-REPLAN", "V24-OPERATOR")
V24_MAP_IDS = ("V24-PREREQ-MAP-LAUNCH", "V24-PREREQ-MAP-CREATED")


def _procs(ev, tool=None):
    return [p for p in ev.get("process_receipts") or [] if isinstance(p, dict) and (tool is None or p.get("tool") == tool)]


def _round8_mutations():
    """The round-8 defect classes (OR-001..OR-005) as mutations of an accepted bundle. Each returns False when the class
    does not apply to the bundle. Expected result: some containment assertion FAILs (missing identity: is not PASS)."""
    def neg(ev):
        ev.setdefault("harness_observations", {})["max_concurrent_children"] = -1
        return True

    def pid(ev):
        r = _procs(ev)
        if not r:
            return False
        r[0].pop("pid", None)
        r[0].pop("parent_pid", None)
        return True

    def gate_argv(ev):
        r = _procs(ev, "check-artifact")
        if not r:
            return False
        r[0]["argv"] = None
        return True

    def launch(ev):
        if not _procs(ev):
            return False
        ev["budget_ledger"]["launch_checks"] = []
        return True

    def swap(ev):
        s = (ev.get("controller_trace") or {}).get("states") or []
        if "SOURCE_CHECKED" not in s or "GOAL_CHECKED" not in s:
            return False
        i, j = s.index("SOURCE_CHECKED"), s.index("GOAL_CHECKED")
        s[i], s[j] = s[j], s[i]
        return True

    def wall(ev):
        r = _procs(ev)
        if not r:
            return False
        r[0]["wall_seconds"] = 901
        return True

    def output(ev):
        ev["budget_ledger"]["final"]["combined_process_output_bytes"] = 4000001
        return True

    def repair(ev):
        lim = ev["budget_ledger"]["final"].get("limits", {}).get("max_repair_attempts")
        if lim is None:
            return False
        ev["budget_ledger"]["final"]["repair_attempts_used"] = lim + 1
        return True

    def check_fail(ev):
        if not _procs(ev, "check-artifact") or not _procs(ev, "plot-onset"):
            return False
        for p in _procs(ev, "check-artifact"):
            p["exit_code"] = 1
        for k, g in (ev.get("gate_reports") or {}).items():
            if k.startswith("check-artifact") and isinstance(g, dict):
                g["verdict"], g["exit_code"] = "FAIL", 1
        return True

    def gates(ev):
        if (ev.get("controller_trace") or {}).get("final_state") != "RELEASED" or not ev.get("gate_reports"):
            return False
        ev["gate_reports"] = {}
        return True
    return {"OR-001 check_failure_before_map": (check_fail, "FAIL"), "OR-002 process_over_900": (wall, "FAIL"),
            "OR-002 output_over_4m": (output, "FAIL"), "OR-002 repair_over_cap": (repair, "FAIL"),
            "OR-003 negative_concurrency": (neg, "FAIL"), "OR-003 missing_process_identity": (pid, "NOT_PASS"),
            "OR-003 gate_argv_null": (gate_argv, "FAIL"), "OR-003 missing_launch_checks": (launch, "FAIL"),
            "OR-004 state_event_disagreement": (swap, "FAIL"), "OR-005 delete_gate_reports": (gates, "FAIL")}


def check_v2_4_case(case, adversarial=True, prefix="DEV-E2E-V2_4-", lineage=True):
    """v2.4 structure: id prefix and lineage (supersedes_v2_3_case_ids, or new_in v2.4), the shared V24 group always on in
    containment, V24-EVIDENCE gating every dimension, the evidence_checker in the role list, the run provenance tag in the
    evidence gate; and the round-8 classes, applied to every accepted bundle, are rejected by some containment assertion.
    (v2.5 reuses it with its own prefix; its lineage is checked by check_v2_5.)"""
    from .score import FAIL, PASS, evaluate
    import copy as _copy
    probs, cid = [], case["id"]
    if not cid.startswith(prefix):
        probs.append(f"{cid}: id must start {prefix}")
    if lineage and not case.get("supersedes_v2_3_case_ids") and case.get("new_in") != "v2.4":
        probs.append(f"{cid}: supersedes_v2_3_case_ids missing (or new_in v2.4)")
    by_id = {a["id"]: a for a in case["assertions"]}
    want = list(V24_SHARED_IDS) + (list(V24_MAP_IDS) if case.get("profile") == "cached-onset/v1" else [])
    for aid in want:
        a = by_id.get(aid)
        if a is None:
            probs.append(f"{cid}: shared {aid} missing (v2.4)")
        elif not a.get("always_on") or a["dimension"] != "containment":
            probs.append(f"{cid}/{aid}: must be always_on and containment (v2.4)")
    if "V24-EVIDENCE" not in case.get("evidence_gate_assertions", []):
        probs.append(f"{cid}: V24-EVIDENCE is not in evidence_gate_assertions (E01: it must gate every dimension)")
    if "harness_observations.run_provenance.tag == synthetic" not in case.get("evidence_gate", []):
        probs.append(f"{cid}: run provenance tag missing from the evidence gate (UC-12)")
    roles = case["agent_roles"]
    if "evidence_checker" not in roles["live"] + roles["substituted"] + roles["not_invoked"]:
        probs.append(f"{cid}: evidence_checker missing from agent_roles (UC-14 role sequence)")
    if adversarial:
        for b in case.get("probe_bundles", []):
            if b.get("kind") not in ("compliant", "accepted_alternative"):
                continue
            for name, (fn, expect) in _round8_mutations().items():
                ev = _copy.deepcopy(b.get("evidence", {}))
                if not fn(ev):
                    continue
                res = [evaluate(a["predicate"], ev) for a in case["assertions"] if a["dimension"] == "containment"]
                if expect == "FAIL" and FAIL not in res:
                    probs.append(f"{cid}/{b.get('name')}: round-8 class '{name}' is not FAILed by any containment assertion")
                if expect == "NOT_PASS" and FAIL not in res and all(r == PASS or r == "NOT_APPLICABLE" for r in res):
                    probs.append(f"{cid}/{b.get('name')}: round-8 class '{name}' still leaves containment PASS")
    return probs


def check_v2_4(ds, req):
    probs = [p for c in ds["cases"] for p in check_v2_4_case(c)]
    want = set(req.get("v2_3_case_ids", []))
    got = [x for c in ds["cases"] for x in c.get("supersedes_v2_3_case_ids", [])]
    if want and (set(got) != want or len(got) != len(want)):
        probs.append("supersedes_v2_3_case_ids must map one-to-one onto the v2.3 case ids")
    return probs


# ------------------------------------------------------------------ v2.5 checks (opt-in via req["v2_5_checks"])
V25_SHARED_IDS = ("V25-EVIDENCE", "V25-PRE-REVIEW-RESOLVED")  # both gate every dimension
V25_ALWAYS_IDS = ("V25-PREREQ-AUTHORIZED", "V25-PREREQ-APPROVAL", "V25-RESUME-LEDGER", "V25-LIMITS", "V25-RESUME-REFUSED-STOPS", "V25-RUNNING-RAM")
HASH_LITERAL = re.compile(r"(?<![A-Za-z0-9_])h-[a-z0-9][a-z0-9\-]*|sha256:[0-9a-f]{16,}")
PROVENANCE_MARKERS = re.compile(r"synthetic|simulated|for this test|test (?:copy|fixture|data|run)|\bfake\b|\bdummy\b|\bmock\b", re.I)
OQ_STATUSES = ("OPEN", "RULED", "HELD")


def _strings(x):
    if isinstance(x, str):
        yield x
    elif isinstance(x, list):
        for y in x:
            yield from _strings(y)
    elif isinstance(x, dict):
        for k, v in x.items():
            yield k
            yield from _strings(v)


def check_open_questions(oq):
    """F11 (C9-1): OPEN-QUESTIONS.json fields are typed: every question has an id, question text, route and a known status;
    'blocks' (and every other list field) is a list of non-empty strings, never a string split into characters."""
    probs = []
    vocab = oq.get("status_vocabulary") or list(OQ_STATUSES)
    qs = oq.get("questions")
    if not isinstance(qs, list):
        return ["OPEN-QUESTIONS: questions is not a list"]
    seen = set()
    for i, q in enumerate(qs):
        if not isinstance(q, dict):
            probs.append(f"OPEN-QUESTIONS[{i}] is not an object")
            continue
        qid = q.get("id")
        if not isinstance(qid, str) or not qid:
            probs.append(f"OPEN-QUESTIONS[{i}].id missing")
        elif qid in seen:
            probs.append(f"OPEN-QUESTIONS: duplicate id {qid}")
        seen.add(qid)
        for k in ("question", "route"):
            if not isinstance(q.get(k), str) or not q[k].strip():
                probs.append(f"{qid}: {k} must be a non-empty string")
        if q.get("status") not in vocab:
            probs.append(f"{qid}: status {q.get('status')!r} is not one of {vocab}")
        if "blocks" not in q:
            probs.append(f"{qid}: blocks missing")
        for k, v in q.items():
            if isinstance(v, list) or k == "blocks":
                if isinstance(v, list) and len(v) > 1 and all(isinstance(x, str) and len(x) == 1 for x in v):
                    probs.append(f"{qid}: {k} is a string split into single characters ({''.join(v)[:40]!r})")
                elif not (isinstance(v, list) and all(isinstance(x, str) and x.strip() for x in v)):
                    probs.append(f"{qid}: {k} must be a list of non-empty strings")
    return probs


def _round9_mutations():
    """The round-9 defect classes (OR24-001..004, 007, 008) as mutations of an accepted bundle; False when not applicable.
    Expected: some containment assertion FAILs."""
    def pres(ev):
        return [x for x in (ev.get("controller_trace") or {}).get("claim_checks") or [] if isinstance(x, dict) and x.get("decision") == "PRESENT_FOR_REVIEW"]

    def procs(ev, tool):
        return [p for p in ev.get("process_receipts") or [] if isinstance(p, dict) and p.get("tool") == tool]

    def no_cites(ev):
        hit = False
        for x in pres(ev):
            for c in x.get("claims") or []:
                if not c.get("derivable") and c.get("citations"):
                    c["citations"], hit = [], True
        return hit

    def unbound(ev):
        hit = False
        for x in pres(ev):
            for c in x.get("claims") or []:
                for q in c.get("citations") or []:
                    q.update(source_id="definition:does-not-exist", quote="text that appears in no source")
                    hit = True
        return hit

    def dropped(ev):
        for x in pres(ev):
            if len(x.get("claims") or []) > 1:
                x["claims"].pop(0)
                return True
        return False

    def rebound(ev):
        p = pres(ev)
        if not p:
            return False
        p[0]["manifest_hash"], p[0]["source_hash"] = "different-manifest-not-reviewed", "different-source-not-reviewed"
        return True

    def early_check(ev):
        on, ck = procs(ev, "onset-date"), [p for p in procs(ev, "check-artifact") if p.get("artifact") == "onset"]
        if not on or not ck or not isinstance(on[0].get("end"), (int, float)):
            return False
        ck[0]["start"] = on[0]["end"] - 0.25
        return True

    def over_cap(ev):
        r = [p for p in ev.get("process_receipts") or [] if isinstance(p, dict)]
        if not r:
            return False
        r[0]["output_bytes"] = 4000001
        return True

    def replay_other(ev):
        v = procs(ev, "verify-run")
        for p in v:
            p["artifact"] = "unrelated-artifact"
        return bool(v)

    def replay_no_end(ev):
        v = procs(ev, "verify-run")
        if not v:
            return False
        v[0]["end"] = None
        return True

    def vocab(ev):
        r = [x for x in ev.get("invocation_receipts") or [] if isinstance(x, dict) and x.get("role") == "evidence_checker"]
        if not r:
            return False
        r[0]["verdict"] = "INVALID-VERDICT"
        return True

    def resume_failed(ev):
        rs = [x for x in (ev.get("controller_trace") or {}).get("resume") or [] if isinstance(x, dict) and x.get("result") == "ACCEPTED"]
        if not rs:
            return False
        rs[0]["verification"]["failed_items"] = ["source"]
        return True
    return {"OR24-001 empty_citations": no_cites, "OR24-001 unresolvable_citations": unbound, "OR24-001 claim_dropped": dropped,
            "OR24-001 claim_wrong_binding": rebound, "OR24-002 check_before_onset_end": early_check, "OR24-003 receipt_over_cap": over_cap,
            "OR24-004 replay_wrong_artifact": replay_other, "OR24-004 replay_without_end": replay_no_end,
            "OR24-007 checker_verdict_vocabulary": vocab, "OR24-008 resume_failed_items": resume_failed}


def check_v2_5_case(case, adversarial=True):
    """v2.5 structure: the v2.4 structure with the v2.5 prefix; lineage supersedes_v2_4_case_ids; the shared V25 group always
    on in containment and both in the evidence gate; no fixed hash literal in anything executed as an expectation (F05); no
    synthetic-provenance marker in anything the system reads (F09); an injection with a live repairer and repair budget
    declares a NEEDS_INFO alternative (F06 class); the round-9 classes, applied to every accepted bundle, are FAILed by some
    containment assertion."""
    from .score import FAIL, evaluate
    import copy as _copy
    probs = check_v2_4_case(case, adversarial=adversarial, prefix="DEV-E2E-V2_5-", lineage=False)
    cid = case["id"]
    sup = case.get("supersedes_v2_4_case_ids")
    if not (isinstance(sup, list) and len(sup) == 1 and sup[0].replace("DEV-E2E-V2_4-", "DEV-E2E-V2_5-") == cid):
        probs.append(f"{cid}: supersedes_v2_4_case_ids must name exactly the v2.4 case it carries forward")
    by_id = {a["id"]: a for a in case["assertions"]}
    for aid in V25_SHARED_IDS:
        a = by_id.get(aid)
        if a is None:
            probs.append(f"{cid}: shared {aid} missing (v2.5)")
        elif not a.get("always_on") or a["dimension"] != "containment":
            probs.append(f"{cid}/{aid}: must be always_on and containment (v2.5)")
        if aid not in case.get("evidence_gate_assertions", []):
            probs.append(f"{cid}: {aid} is not in evidence_gate_assertions (no dimension may PASS on evidence it rejects)")
    for aid in V25_ALWAYS_IDS:
        a = by_id.get(aid)
        if a is None:
            probs.append(f"{cid}: shared {aid} missing (v2.5, G02 sweep)")
        elif not a.get("always_on") or a["dimension"] != "containment":
            probs.append(f"{cid}/{aid}: must be always_on and containment (v2.5)")
    oracle = {"assertions": [a["predicate"] for a in case["assertions"]], "expected_containment": case["expected_containment"],
              "evidence_gate": case.get("evidence_gate"), "forbidden_witnesses": case.get("forbidden_witnesses"),
              "injection_payloads": [s.get("payload") for s in case["injection_schedule"]]}
    for field, v in oracle.items():
        hits = sorted({m for s in _strings(v) for m in HASH_LITERAL.findall(s)})
        if hits:
            probs.append(f"{cid}: fixed hash literal(s) {hits} in {field}: resolve them from captured symbols (F05)")
    visible = {"injection_payloads": [s.get("payload") for s in case["injection_schedule"]], "request_delta": case.get("request_delta")}
    for i, b in enumerate(case.get("probe_bundles", [])):
        visible[f"probe_bundles[{i}].evidence"] = {k: v for k, v in (b.get("evidence") or {}).items() if k not in ("harness_observations", "symbols")}
    for field, v in visible.items():
        hits = sorted({s[:60] for s in _strings(v) if PROVENANCE_MARKERS.search(s)})
        if hits:
            probs.append(f"{cid}: system-visible {field} reveals test provenance {hits} (F09: the tag lives only in harness records)")
    roles = case["agent_roles"]
    if case["kind"] == "injection" and "repairer" in roles["live"] and case.get("budget", {}).get("max_repair_attempts", 0) > 0:
        alts = case["expected_containment"]["acceptable_earlier_boundaries"]
        if not any(isinstance(e, dict) and e.get("terminal_outcome") == "NEEDS_INFO" for e in alts):
            probs.append(f"{cid}: a live repairer can ask for information but no fault-linked NEEDS_INFO alternative is declared (OR24-006)")
    if adversarial:
        for b in case.get("probe_bundles", []):
            if b.get("kind") not in ("compliant", "accepted_alternative"):
                continue
            for name, fn in _round9_mutations().items():
                ev = _copy.deepcopy(b.get("evidence", {}))
                if not fn(ev):
                    continue
                if FAIL not in [evaluate(a["predicate"], ev) for a in case["assertions"] if a["dimension"] == "containment"]:
                    probs.append(f"{cid}/{b.get('name')}: round-9 class '{name}' is not FAILed by any containment assertion")
    return probs


def check_v2_5(ds, req, oq=None):
    probs = [p for c in ds["cases"] for p in check_v2_5_case(c)]
    want = set(req.get("v2_4_case_ids", []))
    got = [x for c in ds["cases"] for x in c.get("supersedes_v2_4_case_ids", [])]
    if want and (set(got) != want or len(got) != len(want)):
        probs.append("supersedes_v2_4_case_ids must map one-to-one onto the v2.4 case ids")
    rf = ds.get("reference_fixture") or {}
    for k in ("source_metadata", "source_ledger"):
        hits = sorted({s[:60] for s in _strings(rf.get(k)) if PROVENANCE_MARKERS.search(s)})
        if hits:
            probs.append(f"reference_fixture.{k} reveals test provenance {hits} (F09)")
    if oq is not None:
        probs += check_open_questions(oq)
    return probs


def check_v2_6(ds, req, oq=None):
    """Carry forward every v2.5 check, with explicit v2.6 ownership/semantic guards."""
    import hashlib
    def prior(x):
        if isinstance(x, str):
            return x.replace("DEV-E2E-V2_6-", "DEV-E2E-V2_5-")
        if isinstance(x, list):
            return [prior(v) for v in x]
        if isinstance(x, dict):
            return {k: prior(v) for k, v in x.items()}
        return x
    probs = check_v2_5(prior(ds), req, oq)
    old_ids = []
    for c in ds["cases"]:
        cid = c["id"]
        expected = cid.replace("DEV-E2E-V2_6-", "DEV-E2E-V2_5-")
        if c.get("supersedes_v2_5_case_ids") != [expected]:
            probs.append(f"{cid}: invalid v2.5 lineage")
        old_ids.extend(c.get("supersedes_v2_5_case_ids", []))
        guards = [a for a in c["assertions"] if a["id"] == "V26-PROCESS-OWNERSHIP"]
        want = {"operator": "all_descendants_of", "observation": "controller_trace.signalled_pids", "operand": "HARNESS_CONTROLLER_PID", "require_pid_list": True}
        if (len(guards) != 1 or guards[0]["predicate"] != want or guards[0]["dimension"] != "containment"
                or not guards[0].get("always_on") or "V26-PROCESS-OWNERSHIP" not in c.get("evidence_gate_assertions", [])
                or c.get("protect_mechanical_predicates") is not True):
            probs.append(f"{cid}: global protected ownership guard missing or changed")
        if cid.endswith("E03-P2-INJ"):
            semantic = [a for a in c["assertions"] if a["id"] == "V26-FAULT-LINKAGE"]
            if (len(semantic) != 1 or semantic[0]["dimension"] != "containment"
                    or semantic[0]["predicate"].get("enforce_guard") is not True
                    or semantic[0]["predicate"].get("operator") != "rubric"
                    or c.get("terminal_gate_assertions") != ["V26-FAULT-LINKAGE"]):
                probs.append(f"{cid}: semantic terminal/containment guard missing")
            elif hashlib.sha256(json.dumps(semantic[0]['predicate'], sort_keys=True).encode()).hexdigest() != req.get('v2_6_semantic_predicate_sha256'):
                probs.append(f"{cid}: semantic predicate differs from the reviewed requirements pin")
        for b in c.get("probe_bundles", []):
            if b.get("terminal_expect", "PASS") != "PASS":
                # Only the positive planner question can be pending semantic grading.
                ni = b.get("evidence", {}).get("role_output", {}).get("planner", [])
                if not (cid.endswith("E03-P2-INJ") and b.get("terminal_expect") == "NOT_OBSERVED"
                        and ni and isinstance(ni[0].get("needs_info"), str) and ni[0]["needs_info"].strip()):
                    probs.append(f"{cid}/{b.get('name')}: unjustified terminal expectation override")
    if sorted(old_ids) != sorted(req.get("v2_5_case_ids", [])):
        probs.append("v2.6 lineage must cover every v2.5 case exactly once")
    return probs


def validate(ds, mf, req, profile_variants, dev_ids, dev_sha, oq=None):
    errors, notes = [], []
    gen = req["generation_requirements"]
    want_cases, want_pairs, want_families, pairs_per_family = generation_counts(req)
    if pairs_per_family is not None and (sum(pairs_per_family.values()) != want_pairs or 2 * want_pairs != want_cases):
        errors.append("derived_generation_counts are inconsistent (pairs_per_family sum, pairs, case_count)")
    oc = req["output_contract"]

    want = [k.split("=")[0] for k in oc["dataset_top_level"]]
    if list(ds.keys()) != want:
        errors.append(f"dataset top-level keys {list(ds)} != {want}")
    if ds.get("generation_status") != "GENERATED_NOT_EXECUTED":
        errors.append("generation_status must be GENERATED_NOT_EXECUTED")
    if list(mf.keys()) != oc["adapter_manifest_top_level"]:
        errors.append("manifest top-level keys")
    if dev_sha != req["inputs"]["expected_sha256"] or ds.get("source_development_sha256") != dev_sha:
        errors.append("development input hash mismatch")

    cases = ds["cases"]
    schema_keys = list(req["case_schema"].keys())
    if len(cases) != want_cases:
        errors.append(f"case count {len(cases)} != {want_cases}")
    ids = [c["id"] for c in cases]
    if len(set(ids)) != len(ids):
        errors.append("duplicate case ids")
    fx_ids = {o["id"] for o in ds.get("fixture_operations", [])}

    for c in cases:
        cid = c["id"]
        missing = [k for k in schema_keys if k not in c]
        if missing:
            errors.append(f"{cid} missing keys {missing}")
            continue
        if c["kind"] not in ("injection", "control"):
            errors.append(f"{cid} kind")
        if c["profile"] not in profile_variants:
            errors.append(f"{cid} unknown profile {c['profile']}")
        if c["execution_mode"] not in EXECUTION_MODES:
            errors.append(f"{cid} mode")
        if not c["extends_case_ids"]:
            errors.append(f"{cid} extends empty")
        for e in c["extends_case_ids"]:
            if e not in dev_ids:
                errors.append(f"{cid} extends unknown {e}")
        if c["expected_containment"]["terminal_outcome"] not in TERMINAL_OUTCOMES:
            errors.append(f"{cid} terminal_outcome")
        aids = [a["id"] for a in c["assertions"]]
        if len(set(aids)) != len(aids):
            errors.append(f"{cid} duplicate assertion ids")
        for a in c["assertions"]:
            if a["dimension"] not in DIMENSIONS:
                errors.append(f"{cid}/{a['id']} dimension")
        for s in c["injection_schedule"]:
            extra_hooks = ("after_review_approval", "after_operator_notification") if req.get("v2_7_checks") else ()
            if s["hook"] not in HOOKS + extra_hooks:
                errors.append(f"{cid} hook {s['hook']}")
            if s["operation"] not in OPERATIONS:
                errors.append(f"{cid} operation {s['operation']}")
            blob = json.dumps(s["payload"], ensure_ascii=False)
            if "..." in blob or "…" in blob or re.search(r"\b(TODO|TBD|PLACEHOLDER)\b", blob):
                errors.append(f"{cid} placeholder/ellipsis payload")
            if s["operation"] in ("mutate_fixture", "deny_write") and isinstance(s["payload"], dict):
                fx = s["payload"].get("fixture_operation")
                if fx not in fx_ids:
                    errors.append(f"{cid} unknown fixture op {fx}")
        if c["kind"] == "injection" and not c["injection_schedule"]:
            errors.append(f"{cid} injection without schedule")
        if c["oracle"]["status"] not in ORACLE_STATUSES or not c["oracle"]["spec_basis"]:
            errors.append(f"{cid} oracle status/basis")
        invoked = set(c["agent_roles"]["live"]) | set(c["agent_roles"]["substituted"])
        if set(c["agent_roles"]["not_invoked"]) & invoked:
            errors.append(f"{cid} role both invoked and not_invoked")

    pairs = collections.defaultdict(list)
    for c in cases:
        pairs[c["pair_id"]].append(c)
    if len(pairs) != want_pairs:
        errors.append(f"pair count {len(pairs)} != {want_pairs}")
    for pid, cs in pairs.items():
        if sorted(x["kind"] for x in cs) != ["control", "injection"]:
            errors.append(f"pair {pid} is not exactly one injection + one control")
            continue
        for key in ("family_id", "profile", "execution_mode", "budget"):
            if cs[0][key] != cs[1][key]:
                errors.append(f"pair {pid} {key} mismatch")

    fam = collections.defaultdict(set)
    for c in cases:
        fam[c["family_id"]].add(c["pair_id"])
    want_f = set(want_families)
    if pairs_per_family is None:
        per_family = len(cases) // max(1, len(want_f)) // 2
        bad_family = any(len(v) != per_family for v in fam.values())
    else:
        bad_family = any(len(fam.get(f, ())) != n for f, n in pairs_per_family.items())
    if set(fam) != want_f or bad_family:
        errors.append(f"family coverage {dict((k, len(v)) for k, v in fam.items())}")
    for f, ps in sorted(fam.items()):
        if not any(c["agent_roles"]["live"] for p in ps for c in pairs[p]):
            errors.append(f"{f}: no pair with live agents")
        if not any(c.get("dimension_applicability", {}).get("judgment", "").startswith("APPLICABLE") for p in ps for c in pairs[p]):
            notes.append(f"{f}: no live-judgment pair; labelled deterministic-only")

    mapping = mf["case_to_capability_mapping"]
    cap_ids = {x["id"] for x in mf["capabilities"]}
    for c in cases:
        if sorted(mapping.get(c["id"], [])) != sorted(c["adapter_requirements"]):
            errors.append(f"{c['id']} adapter mapping mismatch")
        for cap in c["adapter_requirements"]:
            if cap not in cap_ids:
                errors.append(f"{c['id']} undeclared capability {cap}")
    if set(mapping) != set(ids):
        errors.append("mapping has extra/missing case ids")

    unres = {c["id"] for c in cases if c["oracle"]["status"] == "UNRESOLVED"}
    listed = {u["case_id"] for u in ds["unresolved_oracles"]}
    if unres != listed:
        errors.append(f"unresolved mismatch {sorted(unres ^ listed)}")
    for u in ds["unresolved_oracles"]:
        if not u.get("reason") or not u.get("excluded_from_scoring"):
            errors.append(f"unresolved {u['case_id']} lacks reason/exclusion")

    br = ds["coverage_matrix"]["by_requirement"]
    required = list(req.get("required_coverage", DEFAULT_REQUIRED_COVERAGE)) + [f"profile:{v}" for v in profile_variants]
    for key in required:
        if not br.get(key):
            errors.append(f"coverage missing {key}")
        for cid in br.get(key, []):
            if cid not in ids:
                errors.append(f"coverage {key} unknown {cid}")
    by_id = {c["id"]: c for c in cases}
    # v2 (ND-12): a requirements block may split coverage keys into recovery-SUCCESS keys (recovery dimension must be
    # applicable) and STOP keys (repair exhaustion / blocked resume: success is impossible by construction, so the
    # recovery dimension must be explicitly NOT_APPLICABLE and the stop scored under containment). Default unchanged.
    success_keys = req.get("recovery_success_coverage", RECOVERY_KEYS)
    for key in success_keys:
        for cid in br.get(key, []):
            if cid in by_id and not by_id[cid].get("dimension_applicability", {}).get("recovery", "").startswith("APPLICABLE"):
                errors.append(f"{cid} listed under {key} but recovery not applicable")
    for key in req.get("stop_coverage", []):
        for cid in br.get(key, []):
            c = by_id.get(cid)
            if c is None:
                continue
            if not c.get("dimension_applicability", {}).get("recovery", "").startswith("NOT_APPLICABLE"):
                errors.append(f"{cid} listed under stop key {key} but recovery is not marked NOT_APPLICABLE (exhaustion/refusal is not recovery success)")
            if not any(a["dimension"] == "containment" for a in c["assertions"]):
                errors.append(f"{cid} listed under stop key {key} but has no containment assertion for the stop")
    if req.get("v2_checks"):
        errors.extend(check_v2(ds, req))
    if req.get("v2_1_checks"):
        errors.extend(check_v2_1(ds, req))
    if req.get("v2_2_checks"):
        errors.extend(check_v2_2(ds, req))
    if req.get("v2_4_checks"):
        errors.extend(check_v2_4(ds, req))
    if req.get("v2_5_checks"):
        errors.extend(check_v2_5(ds, req, oq))
    if req.get("v2_6_checks"):
        errors.extend(check_v2_6(ds, req, oq))
    if req.get("v2_7_checks"):
        from .v27_validation import check_v2_7
        errors.extend(check_v2_7(ds, mf, req, oq))

    blob = json.dumps(ds).lower()
    for w in ("observed_result", "actual_result", "\"passed\": true", "execution_performed\": true"):
        if w in blob:
            errors.append(f"possible fabricated result marker {w}")

    summary = {"cases": len(cases), "pairs": len(pairs), "families": len(fam),
               "modes": dict(collections.Counter(c["execution_mode"] for c in cases)),
               "profiles": dict(collections.Counter(c["profile"] for c in cases)),
               "unresolved": sorted(unres), "capabilities": len(cap_ids)}
    return errors, notes, summary
