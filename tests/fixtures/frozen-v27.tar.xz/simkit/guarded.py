"""Guarded scoring entry points (v2.2, round-7 G06b: C01a-R01/R02).

simkit/score.py is byte-identical to the scorer the v2.1 record set ships: its SHA256 is pinned by the v2.1 round-6
before/after record, by the round-6 probe program and by the round-7 coordinator reproduction, so v2.2 cannot edit it
without invalidating those records. These wrappers give the same results as score.score_case / score.score_all on
well-formed input and, on input the scorer was never meant to receive, return NOT_OBSERVED instead of raising:

  * a malformed OUTER record (not an object, no/invalid 'status', no case_id, evidence that is neither an object nor
    null) -> run_status MALFORMED_RECORD, every dimension and the terminal NOT_OBSERVED (C01a-R01: KeyError on 'status');
  * malformed event_seq structure (event_seq or event_seq._absent null / of the wrong type) and any other exception
    the scorer raises on a malformed evidence value -> every dimension and the terminal NOT_OBSERVED, with the
    exception named in 'scorer_error' (C01a-R02: TypeError on a null _absent).

Never PASS: the scoring rule "Harness errors, missing evidence, partial coverage and unexecuted cases are never PASS."
"""
from . import score as S

NOT_OBSERVED = S.NOT_OBSERVED
DIMENSIONS = ("judgment", "containment", "recovery", "utility")
RUN_STATUSES = ("EXECUTED", "NOT_EXECUTED", "NOT_IMPLEMENTED", "HARNESS_ERROR")


def record_problem(record, case_id=None):
    """Why an outer record is malformed (None if it is well formed)."""
    if not isinstance(record, dict):
        return f"record is {type(record).__name__}, not an object"
    if record.get("status") not in RUN_STATUSES:
        return f"status {record.get('status')!r} is not one of {RUN_STATUSES}"
    if not isinstance(record.get("case_id"), str) or not record["case_id"].strip():
        return "record must carry a nonempty case_id"
    if case_id is not None and record.get("case_id") != case_id:
        return f"case_id {record.get('case_id')!r} does not name case {case_id}"
    ev = record.get("evidence")
    if ev is not None and not isinstance(ev, dict):
        return f"evidence is {type(ev).__name__}, not an object"
    if isinstance(ev, dict) and "event_seq" in ev:
        seq = ev["event_seq"]
        if seq is not None and not isinstance(seq, dict):
            return f"event_seq is {type(seq).__name__}, not an object"
        if isinstance(seq, dict) and "_absent" in seq and not (isinstance(seq["_absent"], list) and all(isinstance(k, str) for k in seq["_absent"])):
            return "event_seq._absent is not a list of event keys"
    return None


def _undecided(case, run_status, why):
    cid = case.get("id") if isinstance(case, dict) else None
    return {"case_id": cid, "kind": case.get("kind") if isinstance(case, dict) else None,
            "family_id": case.get("family_id") if isinstance(case, dict) else None,
            "run_status": run_status, "oracle_status": (case.get("oracle") or {}).get("status") if isinstance(case, dict) else None,
            "dimensions": {d: NOT_OBSERVED for d in DIMENSIONS}, "assertions": {}, "terminal": NOT_OBSERVED,
            "applicability": {d: (case.get("dimension_applicability") or {}).get(d, "UNSPECIFIED") if isinstance(case, dict) else "UNSPECIFIED" for d in DIMENSIONS},
            "scorer_error": why}


def score_case_guarded(case, record, evaluators=None, refs=None, ratified=None, allow_unratified=False):
    """score.score_case that never raises on a malformed record or evidence value: NOT_OBSERVED instead."""
    why = record_problem(record, case.get("id"))
    if why:
        return _undecided(case, "MALFORMED_RECORD", why)
    try:
        return S.score_case(case, record, evaluators, refs, ratified, allow_unratified)
    except Exception as e:  # noqa: BLE001 - any scorer failure on malformed evidence is NOT_OBSERVED, never PASS
        return _undecided(case, record["status"], f"{type(e).__name__}: {e}")


def score_all_guarded(cases, records, evaluators=None, refs=None, ratified=None, allow_unratified=False):
    """score.score_all with per-case guarding: malformed records are dropped (and reported) before cross-case symbol
    resolution, and one case's failure never aborts the batch."""
    good, bad, seen = [], {}, set()
    for r in records if isinstance(records, list) else []:
        why = record_problem(r)
        cid = r.get("case_id") if isinstance(r, dict) else None
        if why or not isinstance(cid, str):
            if isinstance(cid, str):
                bad[cid] = why or "record has no case_id"
            continue
        if cid in seen:
            bad[cid] = "multiple records for the same case_id; select an explicit attempt before scoring"
        seen.add(cid)
        good.append(r)
    # An ambiguous/malformed control must not supply cross-case comparison symbols either.
    good = [r for r in good if r["case_id"] not in bad]
    out = []
    for c in cases:
        if c["id"] in bad:
            out.append(_undecided(c, "MALFORMED_RECORD", bad[c["id"]]))
            continue
        try:
            out.extend(S.score_all([c], good, evaluators, refs, ratified, allow_unratified))
        except Exception as e:  # noqa: BLE001
            out.append(_undecided(c, "HARNESS_ERROR", f"{type(e).__name__}: {e}"))
    return out
