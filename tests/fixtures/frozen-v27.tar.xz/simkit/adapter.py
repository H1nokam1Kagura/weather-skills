"""The capability interface a harness implements for one system under test.

Each capability ID in an adapter manifest maps to one method. A capability counts as implemented
only if a subclass OVERRIDES its method; the base raises NotImplementedCapability. The runner reads
implemented_capabilities() and marks any case needing a missing one NOT_IMPLEMENTED -- it is never
attempted, so it can never be scored PASS.

This module has no knowledge of any specific system. A system's adapter lives in that system's own
repository, written in a session that may read the implementation; the case writer never sees it.
"""

CAPABILITY_METHODS = {
    "CAP-RECEIPTS": "capture_evidence",
    "CAP-SYMBOLS": "resolve_symbol",
    "CAP-NOT-IMPLEMENTED": None,  # policy, satisfied by the runner itself
    "CAP-DISPOSABLE-FIXTURE": "prepare_fixture",
    "CAP-ROLE-SUBSTITUTE": "substitute_role_output",
    "CAP-ROLE-INPUT-PATCH": "patch_role_input",
    "CAP-LIVE-ROLE": "invoke_live_role",
    "CAP-LEDGER-SEED": "seed_ledger",
    "CAP-TRANSITION-REQUEST": "submit_transition_request",
    "CAP-FIXTURE-OP": "apply_fixture_operation",
    "CAP-GATE-REPORT-PATCH": "patch_gate_report",
    "CAP-INTERRUPT": "interrupt_controller",
    "CAP-RESUME": "request_resume",
    "CAP-METRIC": "inject_metric",
    "CAP-DENY-WRITE": "deny_write",
    "CAP-TOOL-OUTPUT-PATCH": "patch_tool_output",
    "CAP-DECOY": "spawn_decoy",
    "CAP-SHADOW": "drive_shadow_policy",
    "CAP-PROFILE": "select_profile",
    "CAP-REPAIR-CONFIG": "configure_repair",
    "CAP-MIDPROCESS": "arm_midprocess_trigger",
    "CAP-BINDING-PASSTHROUGH": "confirm_binding_passthrough",
    # v2 additions: each is an evidence guarantee a v2 assertion relies on; absent => the case is NOT_IMPLEMENTED
    "CAP-EXHAUSTIVE-WRITES": "assert_exhaustive_write_capture",
    "CAP-SIGNAL-CAPTURE": "capture_signal_targets",
    "CAP-CONTROLLER-HASH": "controller_goal_hash",
    "CAP-REASON-MAP": "map_terminal_reason",
    "CAP-ROLE-OUTPUT-SCHEMA": "map_role_output",
    "CAP-HARNESS-OBS": "observe_harness",
}


class NotImplementedCapability(NotImplementedError):
    pass


class Adapter:
    """Base adapter. Override a method to declare that capability implemented."""

    name = "base"

    # ---- lifecycle every adapter must provide to run anything
    def run_case(self, case, profile):
        """Execute one case end to end, applying its injection_schedule at the named hooks.

        Must return an evidence dict (controller_trace, invocation_receipts, process_receipts,
        gate_reports, filesystem_snapshot, budget_ledger, role_output, artifacts) built ONLY from
        controller/harness observations -- never from model self-reports.
        """
        raise NotImplementedCapability("run_case")

    # ---- capabilities (one per manifest ID)
    def capture_evidence(self, *a, **k): raise NotImplementedCapability("CAP-RECEIPTS")
    def resolve_symbol(self, *a, **k): raise NotImplementedCapability("CAP-SYMBOLS")
    def prepare_fixture(self, *a, **k): raise NotImplementedCapability("CAP-DISPOSABLE-FIXTURE")
    def substitute_role_output(self, *a, **k): raise NotImplementedCapability("CAP-ROLE-SUBSTITUTE")
    def patch_role_input(self, *a, **k): raise NotImplementedCapability("CAP-ROLE-INPUT-PATCH")
    def invoke_live_role(self, *a, **k): raise NotImplementedCapability("CAP-LIVE-ROLE")
    def seed_ledger(self, *a, **k): raise NotImplementedCapability("CAP-LEDGER-SEED")
    def submit_transition_request(self, *a, **k): raise NotImplementedCapability("CAP-TRANSITION-REQUEST")
    def apply_fixture_operation(self, *a, **k): raise NotImplementedCapability("CAP-FIXTURE-OP")
    def patch_gate_report(self, *a, **k): raise NotImplementedCapability("CAP-GATE-REPORT-PATCH")
    def interrupt_controller(self, *a, **k): raise NotImplementedCapability("CAP-INTERRUPT")
    def request_resume(self, *a, **k): raise NotImplementedCapability("CAP-RESUME")
    def inject_metric(self, *a, **k): raise NotImplementedCapability("CAP-METRIC")
    def deny_write(self, *a, **k): raise NotImplementedCapability("CAP-DENY-WRITE")
    def patch_tool_output(self, *a, **k): raise NotImplementedCapability("CAP-TOOL-OUTPUT-PATCH")
    def spawn_decoy(self, *a, **k): raise NotImplementedCapability("CAP-DECOY")
    def drive_shadow_policy(self, *a, **k): raise NotImplementedCapability("CAP-SHADOW")
    def select_profile(self, *a, **k): raise NotImplementedCapability("CAP-PROFILE")
    def configure_repair(self, *a, **k): raise NotImplementedCapability("CAP-REPAIR-CONFIG")
    def arm_midprocess_trigger(self, *a, **k): raise NotImplementedCapability("CAP-MIDPROCESS")
    def confirm_binding_passthrough(self, *a, **k): raise NotImplementedCapability("CAP-BINDING-PASSTHROUGH")
    def assert_exhaustive_write_capture(self, *a, **k): raise NotImplementedCapability("CAP-EXHAUSTIVE-WRITES")
    def capture_signal_targets(self, *a, **k): raise NotImplementedCapability("CAP-SIGNAL-CAPTURE")
    def controller_goal_hash(self, *a, **k): raise NotImplementedCapability("CAP-CONTROLLER-HASH")
    def map_terminal_reason(self, *a, **k): raise NotImplementedCapability("CAP-REASON-MAP")
    def map_role_output(self, *a, **k): raise NotImplementedCapability("CAP-ROLE-OUTPUT-SCHEMA")
    def observe_harness(self, *a, **k): raise NotImplementedCapability("CAP-HARNESS-OBS")

    # ---- introspection
    def implemented_capabilities(self):
        impl = {"CAP-NOT-IMPLEMENTED"}
        for cap, meth in CAPABILITY_METHODS.items():
            if meth and getattr(type(self), meth) is not getattr(Adapter, meth):
                impl.add(cap)
        return impl

    def can_run(self):
        return type(self).run_case is not Adapter.run_case


class NullAdapter(Adapter):
    """Implements nothing: every case comes out NOT_IMPLEMENTED. Useful as a dry run."""
    name = "null"
