"""Oracle ratification: an append-only decision ledger plus proposed amendments.

The brief requires PROPOSED oracles to be reviewed and ratified before scoring, and forbids adjusting
them to make a build pass. So:
  * frozen cases are never edited; amendments are separate, reviewable change sets;
  * an amendment takes effect ONLY when a ledger entry RATIFIES the case with that amendment_id;
  * the effective ratified set is DERIVED from the ledger (last decision per case wins), never stored
    as a flag that can drift from the decisions;
  * an entry whose ratifier is the generating model is rejected: the generator cannot grade itself.
"""
import copy

DECISIONS = ("RATIFY", "REJECT", "DEFER")


class LedgerError(ValueError):
    pass


def check_ledger(ledger, generator_identity, amendments, case_ids):
    errs = []
    gen = (generator_identity or "").lower()
    amd_ids = {a["id"]: a for a in amendments}
    for i, e in enumerate(ledger.get("entries", [])):
        tag = f"entry {i}"
        for k in ("case_id", "decision", "by", "at"):
            if not e.get(k):
                errs.append(f"{tag}: missing {k}")
        if e.get("decision") not in DECISIONS:
            errs.append(f"{tag}: decision must be one of {DECISIONS}")
        scoped = e.get("case_id") == "*"
        if not scoped and e.get("case_id") not in case_ids:
            errs.append(f"{tag}: unknown case {e.get('case_id')}")
        if scoped and not _amd_list(e):
            errs.append(f"{tag}: a '*' entry must name case-set amendments")
        by = str(e.get("by", "")).lower()
        if "claude" in by or (gen and gen.split(" (")[0] in by):
            errs.append(f"{tag}: ratifier '{e.get('by')}' is the generating model; self-ratification is not allowed")
        kind = e.get("reviewer_kind", "human")
        if kind not in ("human", "model"):
            errs.append(f"{tag}: reviewer_kind must be 'human' or 'model'")
        if kind == "model" and not ledger.get("allow_model_ratification", False):
            errs.append(f"{tag}: model-signed entry ('{e.get('by')}') refused: this ledger requires a human to ratify. "
                        "A model's review belongs in a proposed-decisions file that a human transcribes after checking.")
        if e.get("amendment_id") and e.get("amendment_ids"):
            errs.append(f"{tag}: use amendment_id or amendment_ids, not both")
        for aid in _amd_list(e):
            if aid in amd_ids and amd_ids[aid].get("status") == "WITHDRAWN" and e.get("decision") == "RATIFY":
                errs.append(f"{tag}: amendment {aid} is WITHDRAWN and cannot be ratified")
            if aid not in amd_ids:
                errs.append(f"{tag}: unknown amendment {aid}")
            elif scoped != (amd_ids[aid]["case_id"] == "*"):
                errs.append(f"{tag}: amendment {aid} is {'case-set' if amd_ids[aid]['case_id'] == '*' else 'per-case'} scoped; "
                            f"use {'case_id \"*\"' if amd_ids[aid]['case_id'] == '*' else 'its case_id'}")
            elif not scoped and amd_ids[aid]["case_id"] != e.get("case_id"):
                errs.append(f"{tag}: amendment {aid} targets {amd_ids[aid]['case_id']}, not {e.get('case_id')}")
            elif scoped:
                missing = set(amd_ids[aid].get("case_ids", [])) - set(case_ids)
                if missing:
                    errs.append(f"{tag}: amendment {aid} names unknown cases {sorted(missing)}")
    return errs


def requires(amendments):
    """Map amendment id -> ids it depends on (a dependent cannot be applied without its dependency)."""
    return {a["id"]: list(a.get("requires", [])) for a in amendments}


def _amd_list(e):
    if e.get("amendment_ids"):
        return list(e["amendment_ids"])
    return [e["amendment_id"]] if e.get("amendment_id") else []


def effective_decisions(ledger):
    """Last decision per case (case-set '*' entries are tracked per amendment, see effective_cases)."""
    last = {}
    for e in ledger.get("entries", []):
        if e["case_id"] != "*":
            last[e["case_id"]] = e
    return last


def _caseset_ratified(ledger):
    """Case-set amendments in force: last '*' decision per amendment id wins."""
    return set(_caseset_ratified_at(ledger))


def _caseset_ratified_at(ledger):
    """{amendment id: ledger index of the '*' RATIFY that put it in force}."""
    state = {}
    for i, e in enumerate(ledger.get("entries", [])):
        if e["case_id"] == "*":
            for aid in _amd_list(e):
                state[aid] = (e["decision"], i)
    return {aid: i for aid, (d, i) in state.items() if d == "RATIFY"}


def _caseset_last_decision_at(ledger):
    """{amendment id: ledger index of the LAST '*' decision about it, whatever the decision}."""
    last = {}
    for i, e in enumerate(ledger.get("entries", [])):
        if e["case_id"] == "*":
            for aid in _amd_list(e):
                last[aid] = i
    return last


def _last_index(ledger):
    idx = {}
    for i, e in enumerate(ledger.get("entries", [])):
        if e["case_id"] != "*":
            idx[e["case_id"]] = i
    return idx


def _apply(case, change):
    op = change["op"]

    def key(node, k):  # numeric path segments index lists
        return int(k) if isinstance(node, list) else k
    if op == "set":
        node = case
        keys = change["path"].split(".")
        for k in keys[:-1]:
            node = node[key(node, k)]
        last = key(node, keys[-1])
        if isinstance(node, list) and not 0 <= last < len(node):
            raise LedgerError(f"index {last} out of range in {change['path']}")
        node[last] = change["value"]
    elif op == "append":
        node = case
        for k in change["path"].split("."):
            node = node[key(node, k)]
        node.append(change["value"])
    elif op == "replace_assertion":
        for i, a in enumerate(case["assertions"]):
            if a["id"] == change["assertion_id"]:
                case["assertions"][i] = change["value"]
                break
        else:
            raise LedgerError(f"assertion {change['assertion_id']} not in {case['id']}")
    elif op == "add_assertion":
        if any(a["id"] == change["value"]["id"] for a in case["assertions"]):
            raise LedgerError(f"assertion {change['value']['id']} already in {case['id']}")
        case["assertions"].append(change["value"])
    else:
        raise LedgerError(f"unknown amendment op {op}")


def effective_cases(cases, ledger, amendments):
    """Return (cases_with_ratified_amendments_applied, ratified_case_ids). Frozen input is not mutated."""
    amd = {a["id"]: a for a in amendments}
    decisions = effective_decisions(ledger)
    in_force_at = _caseset_ratified_at(ledger)
    in_force_caseset = set(in_force_at)
    case_idx = _last_index(ledger)
    deps = requires(amendments)
    out, ratified = [], set()
    stale = set()
    last_star = _caseset_last_decision_at(ledger)
    for c in cases:
        d = decisions.get(c["id"])
        c2 = copy.deepcopy(c)
        # ANY later case-set decision (ratify OR reject/defer) about an amendment that names this case changes
        # the content the case was reviewed on, so its earlier per-case ratification lapses until re-reviewed
        for aid, i in last_star.items():
            if c["id"] in amd.get(aid, {}).get("case_ids", []) and c["id"] in case_idx and case_idx[c["id"]] < i:
                stale.add(c["id"])
        # case-set amendments in force apply to every case they name, ratified oracle or not
        for aid in sorted(in_force_caseset):
            if amd[aid].get("status") == "WITHDRAWN":
                raise LedgerError(f"{aid} is WITHDRAWN and cannot be applied")
            if c["id"] in amd[aid].get("case_ids", []):
                for ch in amd[aid]["changes"]:
                    _apply(c2, ch)
                # a case-set change ratified AFTER this case's own ratification changes what was reviewed:
                # the case must be re-reviewed before it counts as ratified again
                if c["id"] in case_idx and case_idx[c["id"]] < in_force_at[aid]:
                    stale.add(c["id"])
        if d and d["decision"] == "RATIFY":
            for aid in _amd_list(d):  # applied in the order listed
                if amd[aid].get("status") == "WITHDRAWN":
                    raise LedgerError(f"{aid} is WITHDRAWN and cannot be applied")
                missing = [x for x in deps.get(aid, []) if x not in in_force_caseset]
                if missing:
                    raise LedgerError(f"{aid} requires case-set amendment(s) {missing} to be ratified first")
                for ch in amd[aid]["changes"]:
                    _apply(c2, ch)
            if c2["oracle"]["status"] == "UNRESOLVED":
                raise LedgerError(f"{c['id']}: cannot ratify an UNRESOLVED oracle without an amendment that resolves it")
            if c["id"] not in stale:
                ratified.add(c["id"])
        out.append(c2)
    return out, ratified
