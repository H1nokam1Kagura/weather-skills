"""Dispatch cases to an adapter. The runner never judges; it records what happened.

A case runs only if (a) the adapter can run cases at all and (b) every capability the case needs is
implemented. Otherwise it is recorded NOT_IMPLEMENTED with the missing capabilities named. An
adapter exception is recorded HARNESS_ERROR. Neither is ever passed to the scorer as evidence.
"""
import datetime
import traceback


def run(cases, adapter, profile, only=None):
    impl = adapter.implemented_capabilities()
    records = []
    for c in cases:
        if only and c["id"] not in only:
            continue
        rec = {"case_id": c["id"], "adapter": adapter.name,
               "started_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds")}
        missing = sorted(set(c["adapter_requirements"]) - impl)
        if not adapter.can_run():
            missing = ["run_case"] + missing
        if missing:
            rec.update(status="NOT_IMPLEMENTED", missing_capabilities=missing, evidence=None)
        else:
            try:
                rec.update(status="EXECUTED", evidence=adapter.run_case(c, profile))
            except Exception as e:  # harness error: recorded, never scored as PASS
                rec.update(status="HARNESS_ERROR", error=f"{type(e).__name__}: {e}",
                           traceback=traceback.format_exc(limit=5), evidence=None)
        records.append(rec)
    return records
