"""Derive the evidence contract an adapter must satisfy, from the case set itself.

The contract is COMPUTED from the assertions (plus ratifiable amendments), never hand-written, so it
cannot drift from what the scorer will actually look up. tests check the checked-in copy is current.
"""
import json
import re

from .score import EVIDENCE_ROOTS, decidable

SYMBOL_RE = re.compile(r"HARNESS_[A-Z_]+(?::[A-Za-z0-9_.\-]+)?")
# v2.4: receipt fields the typed whole-run validator (score.run_evidence_findings) reads on every observed receipt
RUN_EVIDENCE_PROCESS_FIELDS = ("tool", "pid", "parent_pid", "argv", "start", "end", "wall_seconds", "exit_code", "output_bytes", "producing")
RUN_EVIDENCE_INVOCATION_FIELDS = ("role", "session_id", "occurrence", "phase", "seq")
STRUCTURES = {
    "controller_trace.terminal.outcome": "Terminal outcome (RELEASED | BLOCKED | NEEDS_INFO | INCOMPLETE); read by the separate terminal check for every executed case.",
    "event_seq": "Map from an event path (exactly as written in a 'before' assertion) to a controller-global monotonic sequence number. Optional key '_absent': list of event paths that provably never occurred.",
    "process_tree": "Map {pid: parent_pid} for every process the controller started or signalled, plus HARNESS_CONTROLLER_PID; used by all_descendants_of.",
    "<path> for 'unchanged'": "An object {\"before\": <hash>, \"after\": <hash>} captured by the harness around the boundary.",
    "symbols": "Map from every HARNESS_* token below to its resolved value, captured from trusted controller/harness state. An unresolved symbol scores NOT_OBSERVED.",
    "invocation_receipts": "A LIST of role-invocation receipts, each {role, session_id, occurrence (1-based per role), phase: 'pre_interrupt'|'post_resume', verdict? (if the role emits one)}.",
    "process_receipts": "A LIST of process receipts, each {tool, argv: list of tokens (never one joined string), flags: parsed map e.g. {'--title': value}, exit_code (int), start, end, pid, parent_pid}.",
    "gate_reports": "A MAP keyed '<tool>(<artifact>)', e.g. 'verify-run(onset)', each the captured report including its 'artifact' identity field and 'checks' list.",
    "artifacts": "A MAP keyed by artifact id; each record ALWAYS carries 'present' (true/false) plus harness-computed fields such as content_hash and nan_mask_matches_source.",
    "indexing": "Path indexes such as [0] are ZERO-based. 'occurrence' fields inside receipts are 1-based counts.",
    "absence": "A filter that matches nothing inside an EXISTING list is an observed absence; a missing list or container is NOT_OBSERVED. Emit empty lists, never omit them, when nothing happened.",
}


def _paths_in(text):
    """Every evidence path mentioned in an observation or condition string (rooted in a known stream).
    Conditions contribute their clause paths, never the whole expression (ND-18)."""
    out = []
    for tok in re.findall(r"(?:count\()?([a-z_][a-z0-9_\-]*(?:[.\[][^\s,;]*)?)", str(text)):
        while tok.count(")") > tok.count("("):  # strip the closing paren of a count(...) wrapper only
            tok = tok[:-1]
        root = tok.split(".")[0].split("[")[0]
        if root in EVIDENCE_ROOTS and root not in ("event_seq", "symbols"):
            out.append(tok)
    return out


def build(dataset, amendments=(), extra_structures=None):
    """extra_structures (v2): additional or refined shape declarations from the case set's requirements; merged
    over STRUCTURES for that contract only, so a case set can tighten shapes without editing another set's contract."""
    cases = {c["id"]: c for c in dataset["cases"]}
    assertions = [(cid, a) for cid, c in cases.items() for a in c["assertions"]]
    # C2b opt-in cases expose legacy gate conditions as contract dependencies.
    # Referenced gate assertions are already in the normal assertion list.
    for cid, case in cases.items():
        if "evidence_gate_assertions" in case and case.get("evidence_gate"):
            assertions.append((cid, {"id": "$EVIDENCE_GATE", "predicate": {
                "operator": "all_of", "observation": "controller_trace",
                "operand": case["evidence_gate"]}}))
    for amd in amendments:
        if amd.get("status") == "WITHDRAWN":
            continue
        for ch in amd["changes"]:
            if ch["op"] in ("replace_assertion", "add_assertion"):
                label = ("case-set" if amd["case_id"] == "*" else amd["case_id"]) + f" ({amd['id']})"
                assertions.append((label, ch["value"]))
    roots, symbols, events, needs_evaluator = {}, {}, {}, []
    for cid, a in assertions:
        p = a["predicate"]
        obs, opnd = p["observation"], p.get("operand")
        for s in SYMBOL_RE.findall(json.dumps([obs, opnd])):
            symbols.setdefault(s, set()).add(cid)
        if p["operator"] == "before":
            for side in (obs.split("==")[0].strip(), opnd):
                events.setdefault(re.sub(r"\.verdict$", "", side), set()).add(cid)
        if p["operator"] == "none_after":  # v2.1: the trusted stop event is an event_seq key the adapter must record
            events.setdefault(obs, set()).add(cid)
        texts = [obs] + ([opnd] if isinstance(opnd, str) else list(opnd) if isinstance(opnd, list) else [])
        if isinstance(p.get("when"), str):
            texts.append(p["when"])
        for t in texts:  # ordering clauses inside implies / matches_any conditions
            for left, right in re.findall(r"(\S+) before (\S+)", str(t)):
                if all(s.split(".")[0].split("[")[0] in EVIDENCE_ROOTS for s in (left, right)):  # skip prose
                    events.setdefault(left, set()).add(cid)
                    events.setdefault(right, set()).add(cid)
        # every path in the observation AND in any condition operand (consequent fields included)
        mentioned = _paths_in(obs)
        if isinstance(p.get("when"), str):
            mentioned += _paths_in(p["when"])
        if p.get("enforce_guard") is True and isinstance(p.get("applies_when"), str):
            mentioned += _paths_in(p["applies_when"])
        if isinstance(p.get("when_list"), str):
            mentioned += _paths_in(p["when_list"])
        if isinstance(p.get("requires_present"), list):  # v2.4 for_each: streams that must be observed
            mentioned += [x for x in p["requires_present"] if isinstance(x, str)]
        if isinstance(p.get("closed_vocabulary"), dict) and isinstance(p["closed_vocabulary"].get("observation"), str):  # v2.5 (F07)
            mentioned.append(p["closed_vocabulary"]["observation"])
        prose = p["operator"] == "rubric" and "grader" in p  # v2 rubric operands are grading prose, never paths
        for t in ([] if prose else [opnd] if isinstance(opnd, str) else opnd if isinstance(opnd, list) else []):
            if isinstance(t, str):
                mentioned += _paths_in(t)
        if isinstance(opnd, dict) and "path" in opnd:
            mentioned.append(opnd["path"])
        if p["operator"] == "run_evidence" and isinstance(opnd, dict):
            # v2.4: the whole-run validator reads every path its spec names, plus the receipt fields it types
            mentioned += [x for k in ("count_fields", "optional_count_fields", "list_streams") for x in opnd.get(k, [])
                          if isinstance(x, str)]
            mentioned += [f"process_receipts[*].{f}" for f in RUN_EVIDENCE_PROCESS_FIELDS]
            mentioned += [f"invocation_receipts[*].{f}" for f in RUN_EVIDENCE_INVOCATION_FIELDS]
            if opnd.get("clock_agreement"):
                mentioned += ["controller_trace.states", "controller_trace.final_state", "controller_trace.terminal.outcome"]
            if opnd.get("launch_coverage"):
                mentioned += [f"budget_ledger.launch_checks[*].{f}" for f in ("tool", "launched", "budget_ok", "free_ram_gib")]
            # v2.5 (schema simkit-run-evidence/2): the cross-record sections read these fields
            pr = opnd.get("process_reconciliation")
            if isinstance(pr, dict):
                mentioned += [f"process_receipts[*].{f}" for f in ("tool", "artifact", "pid", "start", "end", "exit_code", "wall_seconds", "output_bytes")]
                mentioned += [x for x in (pr.get("output_total"), pr.get("concurrency"), pr.get("gate_reports"), pr.get("process_tree"),
                                          pr.get("created_paths")) if isinstance(x, str)]
                mentioned += ["gate_reports.*.exit_code", "gate_reports.*.verdict", "process_receipts[*].parent_pid"]
                if isinstance(pr.get("producing_tools"), list):
                    mentioned.append("process_receipts[*].producing")
                if isinstance(pr.get("artifacts"), str):
                    mentioned += [f"{pr['artifacts']}.*.present", f"{pr['artifacts']}.*.path"]
            if isinstance(opnd.get("checker_vocabulary"), dict):
                role = opnd["checker_vocabulary"].get("role", "evidence_checker")
                mentioned += [f"invocation_receipts[role={role}].verdict", f"role_output.{role}[*].plan_hash",
                              f"role_output.{role}[*].verdicts[*].claim_id", f"role_output.{role}[*].verdicts[*].verdict",
                              "controller_trace.claim_checks[*].evidence_checker_occurrence", "controller_trace.claim_checks[*].plan_hash",
                              "controller_trace.claim_checks[*].claims[*].checker_verdict", "controller_trace.claim_checks[*].claims[*].verdict"]
            if isinstance(opnd.get("resume_verification"), dict):
                rvs = opnd["resume_verification"]
                mentioned += ["controller_trace.resume[*].result", "controller_trace.resume[*].verification.verdict",
                              "controller_trace.resume[*].verification.failed_items", "controller_trace.resume[*].verification.checked_items"]
                if rvs.get("interruption_bound"):
                    mentioned += ["controller_trace.resume[*].initiated_by", "controller_trace.resume[*].interruption_index", "controller_trace.interruptions[*].index"]
                if rvs.get("phase_after_decision"):
                    mentioned += ["invocation_receipts[*].phase", "invocation_receipts[*].seq"]
            ccs = opnd.get("cumulative_counters")
            if isinstance(ccs, dict):
                for side in ("checkpoint", "final"):
                    if isinstance(ccs.get(side), str):
                        mentioned += [f"{ccs[side]}.{f}" for f in ccs.get("fields", [])] + [f"{ccs[side]}.limits"]
            for rl in opnd.get("record_lists") or []:  # V25-CX-001: every typed contract list of records
                if isinstance(rl, dict) and isinstance(rl.get("path"), str):
                    base = rl["path"] if rl["path"].endswith(".*") else rl["path"] + "[*]"
                    mentioned += [f"{base}.{f}" for f in list(rl.get("fields", {})) + list(rl.get("optional_fields") or {})] or [rl["path"]]
            if isinstance(opnd.get("provenance"), dict):  # AR25 / G03: the sources every controller record is checked against
                mentioned += ["controller_trace.plan_validations[*].source", "controller_trace.operator_actions[*].speaker",
                              "controller_trace.operator_actions[*].accepted", "controller_trace.goal_check.verdict",
                              "controller_trace.goal_check.failed_fields", "controller_trace.signalled_pids",
                              "controller_trace.transport_retries[*].before_write", "controller_trace.material_changes[*].to_hash",
                              "controller_trace.diagnoses[*].interruption_indexes", "controller_trace.operator_notifications[*].diagnosis_index",
                              "controller_trace.mechanical_repairs[*].diagnosis_index", "controller_trace.source_rechecks[*].source_hash",
                              "role_output.planner[*].needs_info", "role_output.repairer[*].needs_info",
                              # round 14 (AR25-005..008): the dependency map, repair binding and retry identity read these
                              "controller_trace.resume[*].interruption_index", "controller_trace.resume[*].operator_record_id",
                              "controller_trace.resume[*].initiated_by", "controller_trace.diagnoses[*].fix_action",
                              "controller_trace.diagnoses[*].mechanical", "controller_trace.diagnoses[*].evidenced",
                              "controller_trace.mechanical_repairs[*].action", "controller_trace.mechanical_repairs[*].result",
                              "controller_trace.transport_retries[*].step", "controller_trace.transport_retries[*].attempt",
                              "controller_trace.operator_actions[*].record_id", "controller_trace.operator_actions[*].planner_occurrence"]
            dr = opnd.get("decision_reconciliation")
            if isinstance(dr, dict):  # V25-CX-004: every record a gate decision is reconciled with
                outs_p, recs_p = dr.get("outputs", "role_output"), dr.get("receipts", "invocation_receipts")
                mentioned += [f"{outs_p}.{r}[*].verdict" for r in dr.get("receipt_verdict_roles") or {}] + [f"{recs_p}[*].verdict"]
                for key in ("approval", "release", "failed_gate"):
                    if isinstance(dr.get(key), dict) and isinstance(dr[key].get("path"), str):
                        mentioned.append(dr[key]["path"])
                if isinstance(dr.get("approval"), dict):
                    mentioned.append(f"{outs_p}.{dr['approval'].get('role', 'reviewer')}[*].approved_binding")
                sh = dr.get("shadow")
                if isinstance(sh, dict):
                    mentioned += [f"{sh.get('decisions')}[*].{f}" for f in sh.get("fields", [])]
                    mentioned += [f"{outs_p}.{sh.get('role')}[*].{f}" for f in sh.get("fields", [])]
                cm = dr.get("compilers")
                if isinstance(cm, dict):
                    mentioned += [f"{outs_p}.{r}[*].{cm.get('field', 'goal')}" for r in cm.get("roles", [])] + [f"{cm.get('check')}.failed_fields", f"{cm.get('check')}.verdict"]
                for key in ("plan_routing", "plan_refs"):
                    pr = dr.get(key)
                    if isinstance(pr, dict):
                        mentioned += [f"{pr.get('validations')}[*].plan", f"{pr.get('validations')}[*].plan_hash"]
                        mentioned += [f"{outs_p}.{r}[*].{pr.get('field', 'plan')}" for r in pr.get("roles", [])]
            roc = opnd.get("role_output_counts")
            if isinstance(roc, dict):  # V25-CX-003
                mentioned += [f"{roc.get('outputs', 'role_output')}.*", f"{roc.get('receipts', 'invocation_receipts')}[*].role"]
            if isinstance(opnd.get("terminal_vocabulary"), dict):
                mentioned += ["controller_trace.terminal.outcome", "controller_trace.terminal.failed_gate"]
            cr = opnd.get("claim_resolution")
            if isinstance(cr, dict):
                snap = cr.get("snapshots", "harness_observations.review_snapshots")
                mentioned += [f"{snap}[*].{f}" for f in ["reviewer_occurrence", "plan_claims", "sources[*].source_id", "sources[*].source_hash",
                                                         "sources[*].text"] + list(cr.get("binding_fields", []))]
                mentioned += ["controller_trace.claim_checks[*].decision", "controller_trace.claim_checks[*].reviewer_occurrence",
                              "controller_trace.claim_checks[*].claims[*].claim_id", "controller_trace.claim_checks[*].claims[*].text",
                              "controller_trace.claim_checks[*].claims[*].derivable", "controller_trace.claim_checks[*].claims[*].citations[*].source_id",
                              "controller_trace.claim_checks[*].claims[*].citations[*].source_hash",
                              "controller_trace.claim_checks[*].claims[*].citations[*].quote", "controller_trace.active_approval.reviewer_occurrence"]
                mentioned += [f"controller_trace.claim_checks[*].{f}" for f in cr.get("claim_check_fields", [])]
                if cr.get("bind_approval"):
                    mentioned += [f"controller_trace.active_approval.{f}" for f in cr.get("binding_fields", [])]
        for path in dict.fromkeys(mentioned):
            root = path.split(".")[0].split("[")[0]
            roots.setdefault(root, {}).setdefault(path, set()).add(f"{cid}/{a['id']}:{p['operator']}")
        if not decidable(p):
            needs_evaluator.append(f"{cid}/{a['id']}: {p['operator']} on {obs}")
    return {
        "schema_version": "simkit-evidence-contract/1",
        "derived_from": {"dataset_cases": len(cases), "amendments": [a["id"] for a in amendments]},
        "rule": "Evidence is built ONLY from controller and harness observations. Model self-reports are never evidence. A missing stream scores NOT_OBSERVED, never PASS.",
        "streams": {r: {o: sorted(v) for o, v in sorted(obs.items())} for r, obs in sorted(roots.items())},
        "symbols": {s: sorted(v) for s, v in sorted(symbols.items())},
        "event_seq_keys": {e: sorted(v) for e, v in sorted(events.items())},
        "structures": dict(STRUCTURES, **(extra_structures or {})),
        "needs_system_evaluator": sorted(needs_evaluator),
        "needs_system_evaluator_note": "Computed by simkit.score.decidable: predicates whose conditions use prose verbs or dangling paths outside the generic grammar (==, !=, contains, lacks, 'and', 'any'). They score NOT_OBSERVED until an evaluator is supplied. Frozen-case entries superseded by a ratified amendment drop out once the ledger ratifies it.",
    }


def to_markdown(c):
    lines = ["# Evidence contract (generated - do not edit)", "",
             f"Derived from {c['derived_from']['dataset_cases']} cases and amendments {', '.join(c['derived_from']['amendments']) or 'none'}.", "",
             c["rule"], "", "## Streams", ""]
    for r, obs in c["streams"].items():
        lines.append(f"### `{r}` ({len(obs)} paths)")
        for o, uses in obs.items():
            lines.append(f"- `{o}` - {len(uses)} use(s)")
        lines.append("")
    lines += ["## Symbols", ""] + [f"- `{s}` - {', '.join(v)}" for s, v in c["symbols"].items()] + [""]
    lines += ["## event_seq keys", ""] + [f"- `{e}`" for e in c["event_seq_keys"]] + [""]
    lines += ["## Structures", ""] + [f"- **{k}**: {v}" for k, v in c["structures"].items()] + [""]
    lines += ["## Needs a system evaluator", "", c["needs_system_evaluator_note"], ""] + [f"- {x}" for x in c["needs_system_evaluator"]] + [""]
    return "\n".join(lines)
