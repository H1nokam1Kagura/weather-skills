"""simkit command line.

  validate      --caseset DIR --dataset DS --manifest MF
  contract      --caseset DIR --dataset DS            (rewrites DIR/EVIDENCE_CONTRACT.{json,md}; generated files)
  ledger-check  --caseset DIR --dataset DS            (ratification ledger + amendments well-formed, no self-ratification)
  dry-run       --caseset DIR --dataset DS [--adapter mod:Class] [--allow-unratified]
  score         --caseset DIR --dataset DS --records RECORDS.json [--allow-unratified]
  probes        --caseset DIR --dataset DS            (v2: every case's probe_bundles prove its assertions' scope)

Nothing here executes a candidate system; dry-run uses NullAdapter unless told otherwise.
"""
import argparse
import hashlib
import importlib
import json
import os
import sys

from . import contract as contract_mod
from .core import strict_load
from .profile import Profile
from .ratify import check_ledger, effective_cases
from .runner import run
from .guarded import score_all_guarded
from .score import summarize
from .validate import validate

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def load_caseset(caseset):
    req = strict_load(os.path.join(caseset, "requirements.json"))
    profile = Profile.load(os.path.join(ROOT, "profiles", req["profile"], "profile.json"))
    amd_path = os.path.join(caseset, "amendments.json")
    led_path = os.path.join(caseset, "ratification-ledger.json")
    amendments = strict_load(amd_path)["amendments"] if os.path.exists(amd_path) else []
    ledger = strict_load(led_path) if os.path.exists(led_path) else {"entries": []}
    return req, profile, amendments, ledger


def profile_refs(profile, cases):
    refs = {}
    for c in cases:
        for a in c["assertions"]:
            o = a["predicate"].get("operand")
            if isinstance(o, str) and o.startswith("reference_fixture."):
                node = profile.reference_fixture
                try:
                    for k in o.split(".")[1:]:
                        node = node[k]
                    refs[o] = node
                except (KeyError, TypeError):
                    pass
    return refs


def _dev(req):
    raw = open(req["inputs"]["allowed_development_file"], "rb").read()
    return {c["id"] for c in json.loads(raw)["development_cases"]}, hashlib.sha256(raw).hexdigest()


def _adapter(spec):
    mod, _, cls = spec.rpartition(":")
    return getattr(importlib.import_module(mod), cls)()


def main(argv=None):
    ap = argparse.ArgumentParser(prog="simkit")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("validate", "contract", "ledger-check", "dry-run", "score", "probes"):
        p = sub.add_parser(name)
        p.add_argument("--caseset", required=True)
        p.add_argument("--dataset", required=True)
        if name == "validate":
            p.add_argument("--manifest", required=True)
        if name == "dry-run":
            p.add_argument("--adapter", default="simkit.adapter:NullAdapter")
        if name == "score":
            p.add_argument("--records", required=True)
        if name in ("dry-run", "score"):
            p.add_argument("--allow-unratified", action="store_true",
                           help="score PROPOSED oracles anyway (development only; output is flagged as not a scored result)")
    fx = sub.add_parser("fixture", help="write a synthetic, CHIRPS-identical fixture into a NEW directory (UC-12)")
    fx.add_argument("--profile", default="cached-onset")
    fx.add_argument("--out", required=True, help="data directory the system reads (precip.nc only)")
    fx.add_argument("--harness-out", default=None, help="harness-side directory (manifest.json, expected_onset.nc); default <out>.harness")
    fx.add_argument("--seed", type=int, default=20251001)
    a = ap.parse_args(argv)

    if a.cmd == "fixture":
        from .fixtures import onset_synth
        prof = Profile.load(os.path.join(ROOT, "profiles", a.profile, "profile.json"))
        m = onset_synth.write(onset_synth.generate(prof, seed=a.seed), a.out, a.harness_out)
        print(json.dumps({"out": a.out, "harness_out": m["harness_dir"], "content_sha256": m["content_sha256"],
                          "classes": {k: v["cells"] for k, v in m["classes"].items()}}))
        return 0

    req, profile, amendments, ledger = load_caseset(a.caseset)
    ds = strict_load(a.dataset)

    if a.cmd == "validate":
        dev_ids, dev_sha = _dev(req)
        oq_path = os.path.join(a.caseset, "OPEN-QUESTIONS.json")
        oq = strict_load(oq_path) if (req.get("v2_5_checks") or req.get("v2_6_checks") or req.get("v2_7_checks")) and os.path.exists(oq_path) else None
        errors, notes, summary = validate(ds, strict_load(a.manifest), req, list(profile.variants), dev_ids, dev_sha, oq)
        print(json.dumps({"errors": errors, "notes": notes, **summary}, indent=1))
        return 1 if errors else 0

    if a.cmd == "probes":
        from .validate import check_probe_bundles
        refs = profile_refs(profile, ds["cases"])
        probs = [p for c in ds["cases"] for p in check_probe_bundles(c, refs)]
        print(json.dumps({"cases": len(ds["cases"]), "problems": probs}, indent=1))
        return 1 if probs else 0

    if a.cmd == "contract":
        c = contract_mod.build(ds, amendments, req.get("contract_structures_extra"))
        jp, mp = os.path.join(a.caseset, "EVIDENCE_CONTRACT.json"), os.path.join(a.caseset, "EVIDENCE_CONTRACT.md")
        with open(jp, "w", encoding="utf-8", newline="\n") as f:
            json.dump(c, f, ensure_ascii=False, indent=2, allow_nan=False)
            f.write("\n")
        with open(mp, "w", encoding="utf-8", newline="\n") as f:
            f.write(contract_mod.to_markdown(c))
        print(json.dumps({"written": [jp, mp], "streams": len(c["streams"]), "symbols": len(c["symbols"]), "event_seq_keys": len(c["event_seq_keys"])}))
        return 0

    errs = check_ledger(ledger, ds["generator_metadata"].get("observed_model"), amendments, {c["id"] for c in ds["cases"]})
    if a.cmd == "ledger-check":
        print(json.dumps({"errors": errs, "entries": len(ledger.get("entries", [])), "amendments": [x["id"] for x in amendments]}, indent=1))
        return 1 if errs else 0
    if errs:
        print(json.dumps({"ledger_errors": errs}, indent=1))
        return 1
    cases, ratified = effective_cases(ds["cases"], ledger, amendments)
    refs = profile_refs(profile, cases)

    if a.cmd == "dry-run":
        records = run(cases, _adapter(a.adapter), profile)
    else:
        records = strict_load(a.records)
    # v2.2 (G06b): the guarded entry point never raises on a malformed record; it scores it NOT_OBSERVED
    scored = score_all_guarded(cases, records, refs=refs, ratified=ratified, allow_unratified=a.allow_unratified)
    print(json.dumps({"summary": summarize(scored), "ratified_cases": len(ratified),
                      "scored": scored if a.cmd == "score" else None}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
