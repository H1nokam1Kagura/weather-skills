"""Structural checks for the bounded v2.7 closure; preserves inherited checks."""
import hashlib
import importlib.util
import json
from pathlib import Path


def check_v2_7(ds,mf,req,oq=None):
    from .validate import check_v2_6
    def prior(x):
        if isinstance(x,str): return x.replace('DEV-E2E-V2_7-','DEV-E2E-V2_6-')
        if isinstance(x,list): return [prior(v) for v in x]
        if isinstance(x,dict): return {prior(k):prior(v) for k,v in x.items()}
        return x
    errors=check_v2_6(prior(ds),req,oq)
    old_ids=[]
    mapping=mf.get('case_to_capability_mapping',{})
    rubric_pins={}
    for c in ds['cases']:
        cid=c['id']
        lineage=c.get('supersedes_v2_6_case_ids',[])
        if lineage != [cid.replace('DEV-E2E-V2_7-','DEV-E2E-V2_6-')]:
            errors.append(cid+': invalid v2.6 lineage')
        old_ids.extend(lineage)
        if 'CAP-SIGNAL-CAPTURE' not in c['adapter_requirements'] or 'CAP-SIGNAL-CAPTURE' not in mapping.get(cid,[]):
            errors.append(cid+': required signal capture absent')
        if sorted(mapping.get(cid,[])) != sorted(c['adapter_requirements']):
            errors.append(cid+': adapter mapping mismatch')
        # Older cases legitimately mix live and substituted occurrences of a role.
        # NEW-05's specific E15 role contradiction is checked by validate_schedules.
        for a in c['assertions']:
            if a['predicate']['operator']=='rubric':
                rubric_pins[cid+'/'+a['id']]=hashlib.sha256(json.dumps(a['predicate'],sort_keys=True).encode()).hexdigest()
    if sorted(old_ids)!=sorted(req.get('v2_6_case_ids',[])):
        errors.append('v2.7 lineage must cover all v2.6 cases exactly once')
    if rubric_pins!=req.get('v2_7_rubric_predicate_sha256'):
        errors.append('v2.7 rubric predicates differ from requirements pins')
    unresolved={u['id']:u for u in mf['unresolved_contracts']}
    u12=unresolved.get('UC-12',{})
    if u12.get('blocks') and all(isinstance(x,str) and len(x)==1 for x in u12['blocks']):
        errors.append('UC-12 blocks are character-split')
    u16=json.dumps(unresolved.get('UC-16',{})).lower()
    if 'remains held' in u16 or 'tolerant accounting unchanged' in u16:
        errors.append('UC-16 stale held/tolerant guidance')
    path=Path(__file__).resolve().parents[1]/'casesets/cached-onset-e2e-v2_7/schedule_fixes.py'
    spec=importlib.util.spec_from_file_location('v27_schedule_validation',path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    errors.extend(module.validate_schedules(ds,mf,req))
    return errors
